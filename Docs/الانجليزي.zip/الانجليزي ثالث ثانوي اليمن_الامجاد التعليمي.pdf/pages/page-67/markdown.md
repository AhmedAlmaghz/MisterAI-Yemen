ARTS 9

# A poem

# LEISURE

by William Henry Davies 1871-1940

What is this life if, full of care,
We have no time to stand and stare.

No time to stand beneath the boughs
And stare as long as sheep or cows.

No time to see, when woods we pass,
Where squirrels hide their nuts in grass.

No time to see, in broad daylight,
Streams full of stars like skies at night.

No time to turn at Beauty's glance,
And watch her feet, how they can dance.

No time to wait till her mouth can
Enrich that smile her eyes began.

A poor life this if, full of care,
We have no time to stand and stare.

|  care | worry  |
| --- | --- |
|  stare | look closely  |
|  boughs | branches  |
|  squirrels | small animals  |
|  broad daylight | full light of day  |
|  streams | small rivers  |

![img-94.jpeg](img-94.jpeg)

Listen to the poem. Does listening help you to understand it?

# Discussion

- Do you agree with the poet's view?
- Add ones stanza (two lines) to this poem.

61