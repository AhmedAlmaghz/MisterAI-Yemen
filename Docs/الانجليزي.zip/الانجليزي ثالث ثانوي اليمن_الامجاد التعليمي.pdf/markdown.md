**Republic Of Yemen**

Ministry Of Education
and Scientific Research

![img-0.jpeg](img-0.jpeg)

# **ENGLISH COURSE**

## **Pupil’s Book 6**

**All copyrights reserved**

**by**

**Ministry Of Education and Scientific Research**

**2026 - 1447**

تم تحميل ورفع المادة على منصة

# الامجاد التعليمي

للعودة الى الموقع اكتب في بحث جوجل

![img-1.jpeg](img-1.jpeg)

الامجاد التعليمي

الإدارة العامة للمناهج

11

# Contents

## Unit 1 Describing things

|  Shapes, coverings and materials | 1 | **Arts reader** |   |
| --- | --- | --- | --- |
|  Lost | 2 | A difficult choice? | 51  |
|  An unusual animal | 3 | Proverbs and idioms | 52  |
|  Language review 1 | 4 |  |   |
|  The countryside | 5 | **Science reader** |   |
|  A drive in the countryside | 6 | Acids and alkalis | 65  |
|  Language review 2 | 7 | States of matter | 66  |
|  A view from a window | 8 |  |   |

## Unit 2 Reporting events

|  Newspaper headlines | 9 | **Arts reader** |   |
| --- | --- | --- | --- |
|  Today's news | 10 | Telford Hall Episode 1 | 53  |
|  Don and Debbie: dreamers | 11 | A famous play by Shakespeare | 54  |
|  Language review 3 | 12 |  |   |
|  Natural disasters | 13 | **Science reader** |   |
|  A newspaper report | 14 | Light | 67  |
|  Language review 4 | 15 | Sound | 68  |
|  Armenia - 7, December 1988 | 16 |  |   |

## Unit 3 Looking for a job

|  Getting work experience | 17 | **Arts reader** |   |
| --- | --- | --- | --- |
|  Thinking about the future | 18 | Telford Hall Episode 2 | 55  |
|  Getting careers advice | 19 | Critics and criticism | 57  |
|  Language review 5 | 20 |  |   |
|  Jobs and qualities | 21 | **Science reader** |   |
|  Applying for a job | 22 | Arab scientists | 69  |
|  Language review 6 | 23 | Vaccinations | 70  |
|  A business letter | 24 |  |   |

## Unit 4 Tables, flow charts and diagrams

|  Food | 25 | **Arts reader** |   |
| --- | --- | --- | --- |
|  Learning to cook | 26 | Telford Hall Episode 3 | 58  |
|  Agriculture in Yemen | 27 | Calligraphy | 60  |
|  Language review 7 | 28 |  |   |
|  Words and more words | 29 | **Science reader** |   |
|  Investigating the world around us | 30 | Experimental procedures | 71  |
|  Language review 8 | 31 | Internal combustion engine | 72  |
|  Frozen peas | 32 |  |   |

## Unit 5 Working things out

|  Word sets | 33 | **Arts reader** |   |
| --- | --- | --- | --- |
|  Possibilities | 34 | A poem | 61  |
|  Puzzles and riddles | 35 | Strange happenings | 62  |
|  Language review 9 | 36 |  |   |
|  The mystery of the *Mary Celeste* | 37 | **Science reader** |   |
|  What could have happened? | 38 | The Moon | 73  |
|  Language review 10 | 39 | Radioactivity | 74  |
|  Tracks in the sand | 40 |  |   |

## Unit 6 Looking back

|  Emergencies in the news | 41  |
| --- | --- |
|  A lucky escape | 42  |
|  Accident at Jebel Kebir | 43  |
|  Saving Anwar | 44  |
|  How a hospital works | 45  |
|  Working in public service | 46  |
|  Huge changes in Libyan health care | 47  |
|  Discovering Yemen | 48  |
|  Tourism and the future | 49  |
|  **Arts reader** | 50-62  |
|  **Science reader** | 64-74  |

--

الإدارة العامة للمناهج

![Logo of the National Consultative Assembly of Iran, featuring a stylized 'M' and 'C' inside a circle.]()---

UNIT 1 DESCRIBING THINGS

1.1

# Shapes, coverings and materials

Here are some words to describe things. Match them with the pictures and write your answers in Workbook activity A.

Shapes

![img-2.jpeg](img-2.jpeg)

Animal coverings

![img-3.jpeg](img-3.jpeg)

Made of

![img-4.jpeg](img-4.jpeg)

Can you describe other things using any of the words above?
Make sentences like these:

An orange is around.
A dog has hair.
A window is made of glass.

Now do activity B in the Workbook.

1

1.3

# Lost

**Listen to how the passenger speaks. How does he feel? Answer the questions in Workbook activity A. Listen and repeat the conversation.**

**Passenger:** Excuse me! Excuse me, miss!  
 **Clerk:** Can I help you, sir?  
 **Passenger:** Yes. I've just got off the plane from Paris, but my luggage hasn't arrived yet.  
 **Clerk:** Can you describe your luggage, sir?  
 **Passenger:** What am I going to do? No clothes! Nothing!  
 **Clerk:** Calm down, sir. There's no point in getting upset. Now, can you describe your luggage?  
 **Passenger:** Two suitcases.  
 **Clerk:** Are they the same size?  
 **Passenger:** No. One is bigger than the other.  
 **Clerk:** Are they the same colour?  
 **Passenger:** Well, they're both green, but the smaller one is a very light green.  
 **Clerk:** Ok. What shape are they?  
 **Passenger:** The larger one is rectangular. The smaller one is more square-looking.  
 **Clerk:** Now, don't worry, sir. Give me your luggage tags and we'll soon find them.

![img-5.jpeg](img-5.jpeg)

**Listen to how the girl speaks. How does she feel? Answer the question in Workbook activity C. Listen and repeat the conversation.**

![img-6.jpeg](img-6.jpeg)

**Girl:** Excuse me, officer. Can you help me, please? My name is June, and I've lost my sister, Kate.  
 **Officer:** Oh, dear! How old is she?  
 **Girl:** Ten. She's my twin sister. She's the same age as me.  
 **Officer:** And does she look the same as you?  
 **Girl:** No, not really. She's not as tall as me. And she's a little bit fatter. She eats a lot you see.  
 **Officer:** Is her hair the same colours as yours?  
 **Girl:** Yes, but mine isn't as long as hers. Hers is much longer.  
 **Officer:** What is she wearing?  
 **Girl:** The same as I am ... except her T-shirt is red.  
 **Officer:** And when did you last see her?  
 **Girl:** Oh. About half an hour ago.  
 **Officer:** All right. Don't worry. Come along with me and we'll soon find your sister.  
 **Girl:** Ok. Thank you.

**Take turns to describe similar objects or people.**

**Now do activities C and D in the Workbook.**

2

## An unusual animal

1.4

Look at the pictures and the title of the magazine article.
What do you think the article is about? What or who is Rama?

# Rama - the cama

## The cat family

![img-7.jpeg](img-7.jpeg)

![img-8.jpeg](img-8.jpeg)

## The dog family

![img-9.jpeg](img-9.jpeg)

![img-10.jpeg](img-10.jpeg)

Animals are divided into families. The house-cat is of the same family as its much bigger cousins, the lions of Africa and the tigers of India. The dog, the wolf and the jackal are part of the dog family. If animals are part of the same family, it is sometimes possible to crossbreed them to make a new animal. This was done several years ago when a lion was crossbred with a tiger, giving us a new animal called a 'liger'. Now, it has been done again. The new animal is called a 'cama', and has been given the name Rama.

Rama the cama was born in Dubai in January, 1998. It is a cross between a male camel and a female llama. Although they are from the same family of animals, they are very different. Camels live mainly in hot countries like Arabia, whereas llamas live in mountainous parts of South America where it gets very, very cold. Because of the intense cold at heights of 8,000 metres, llamas have coats of long, heavy wool.

So what does Rama look like? Unlike its father, it has no hump on its back. Like its father, it has the short ears and the long tail of the camel. It is bigger than a llama but not as big as a camel. However, the wool coat of the llama, which is very valuable, unlike the hair coat of the camel, which has little value.

![img-11.jpeg](img-11.jpeg)

The most
well-known
crossbreed

![img-12.jpeg](img-12.jpeg)

**Read the article. Then answer these questions.**

Is it possible to crossbreed a cat and a dog?

Why would camas like Rama find it hard to live in the wild in Arabia?

Is it right to crossbreed animals to make new animals? What do you think?

**Now do activities A and B in the Workbook.**

3

1.5

# Language review 1

## 1 Comparison

- • Comparative and superlative forms of adjectives
The most common way to compare things is to use these forms of the adjective.

**Examples:** Hassan is **older than** me.
Yousif is **the oldest** boy in the class.

- • *as*
We use a positive statement with *as* to say that things are equal. We use a negative statement (*as* + *not*) to show that things are not equal.

**Examples:** My sister is **as tall as** me.
My friends are **as** interested in football **as** I am.
My car is **not as fast as** yours.

**Note:** This is the same as saying: My car is *slower* than yours.

- • *same*
This word shows that things are equal. It can also be used in a negative statement.

**Examples:** My sister is the **same** height as me.
My cousin is **not the same** age as me.

**Note:** The word *same* is followed by a noun, not an adjective.
The word can also be used at the end of a sentence.

**Examples:** These two colours are/aren't the **same**.

- • *like/unlike*

The two words are not adjectives but they are used to make comparisons.

**Examples:** **Like my father**, I am interested in sports. **Unlike my father**,
I am not interested in football.

**Note:** The underlined phrases can be used at the end of a sentence or at the beginning. In both cases, a comma separates them from the rest of the sentence.

## 2 Contrast

- • *however/although*

These two words can be used to give the same meaning as *but*.

**Examples:** **Although** he worked hard, he didn't pass his exam.
He worked hard. **However**, he didn't pass his exam.

**Note:** They contrast unexpected relationships between two actions or events.

- • *whereas*

This word can be used to give the same meaning as *but*.

**Examples:** **Whereas** Ahmed worked hard, his brother didn't.

**Note:** It can only be used to describe opposites.

**Find examples of comparison and contrast in the texts.**

**Now do activities A, B and C in the Workbook.**

4

# The countryside

1.6

Here are some words to describe the weather.
Match them with the pictures in Workbook activity A.

A rainy weather

B a misty day

C a sunny afternoon

D a windy evening

![img-13.jpeg](img-13.jpeg)

![img-14.jpeg](img-14.jpeg)

![img-15.jpeg](img-15.jpeg)

![img-16.jpeg](img-16.jpeg)

Here are some names of things you can see in the countryside.
Match them with the pictures in Workbook activity A.

A a stream

B a mountain

C farmland

D a river

E a coastline

F a valley

G a desert

H a hill

![img-17.jpeg](img-17.jpeg)

Look at the pictures. Try to describe what you can see.
Now do activities B and C in the Workbook.

5

SOM

15

## A drive in the countryside

**Read this description. As you read, try to imagine the scene as the driver travels through the countryside.**

Last year, I spent my holiday in Wales, where the scenery is wonderful. One bright, sunny day I decided to go for a drive. I drove out of town along the coast road. The sea was to my left about two kilometres away. Between the sea and the road was farmland. In one field there were a lot of cows with their heads down, grazing. In another field, closer to me, a farmer on a tractor was ploughing. Behind the plough were lots of birds, looking for something to eat in the newly turned over soil.

To the right of the road were some high, rocky hills. I turned off the main coast road and soon I was in a deep valley. Hills rose on both sides of the road. At first, the road climbed gently, but as I drove higher, it got steeper and steeper. Further up I could see a river to the left. I drove higher and higher and the river got narrower and narrower, until it was just a stream.

Near the top of the hill, the road ended. I got out of the car and climbed to the peak to look at the view of the valley below. At the end of the valley I could see the farmer on his tractor. Away in the distance I could just make out the sea. As I looked, I began to feel hungry and thirsty.

I went back down to the stream below. The water was cold and clear and tasted very good. I sat on a rock to eat my sandwiches, my back warmed by the sun. Suddenly a cloud came across the sun. I felt cold. A mist came down over the mountain. Soon I would not be able to see where I was going. I knew I had to leave. I put away a half-eaten sandwich, got into the car and drove back down the valley.

**Read the first paragraph carefully and think about how it is organized.**

Which side of the road did the writer look at first?

What was furthest away from him?

What was nearest to him?

**Then look at how the other paragraphs are organized.**

**Now do activities A and B in the Workbook.**

![A small circular logo with a stylized 'A' inside.]()

# Language review 2

1.10

When you are describing something in writing, it is important that you paint a picture in the reader's mind.

## 1 Description

- adjective order

When using two or more adjectives to describe something, follow this order:

1 Opinion

good, bad, beautiful, amazing, horrible

2 Size/build

big, heavy, short, long

3 Age

young old, ten-year-old

4 Shape

round, rectangular, fat

5 Colour

black, dark green, blue-grey

6 Nationality

Yemeni, Qatari, Indian

7 Material

paper, wool, glass

Examples: A beautiful, old, Yemeni building
a heavy, round, black stone

- emphasis

You can make your description stronger by repeating some words, for example, comparative adjectives and adverbs.

Examples: He drove faster and faster, and I got more and more worried.
Up, up and up went the balloon, until it was a small dot in the sky.

## 2 Information focus

You can change the focus of a sentence by moving adjectival or adverbial phrases.
You may want to do this for reasons of style or emphasis.

Examples: There were lots of goats on top of the hill. →
On top of the hill were lots of goats

Some of the hills were to the right of the road. →
To the right of the road were some hills.

Note: In the second example the subject and the verb change places.
This happens only when using the verb to be.

## 3 Joining sentences

- with the -ing form

Examples: The children ran out of school. They were laughing and
shouting happily. →
The children ran out of school, laughing and
shouting happily.

Find examples of description, changed focus and joined
sentences in the text.

Now do activities A, B and C, in the Workbook.

7

WOM

1.11

## A view from a window

Look at the four paragraphs. Decide what part of the view the girl is describing in each.

![img-18.jpeg](img-18.jpeg)

It was six o'clock in the morning. Jane opened the curtains of her bedroom window and looked out. She did this every time she got up, because it was a quiet time and she liked the view. Far away on the horizon was a wall of white mist. Jane knew that it would disappear as the day got hotter.

A little bit nearer was the wood that Jane loved. She often walked home through that wood after school, trying to count the trees. She knew that there were hundreds of them but she did not know how many. As she stood at the window she could hear the birds in the trees, even from a distance. They were already awake, singing their early morning songs.

Jane looked to her left. In a nearby field there were more than twenty cows. They were all still lying down, chewing the cud. 'A cow's mouth never stops moving', she thought. In the field next to the cows were two horses, a mare and her two-week-old foal. Jane watched for a few minutes as he suckled his mother, getting plenty of rich milk that would make him grow.

Just below Jane's window a number of chickens were cackling noisily, scratching in the dust with their claws and pecking with their beaks. Jane did not know what they could find to eat. They were fed twice a day, but that did not stop them from looking for more. Suddenly Jane was hungry. It was time to get dressed and have breakfast.

**'Far away' is a phrase telling you where things are. Find similar phrases in the passage. Does the description move from near to far or the other way around?**

**Now do activities A and B in the Workbook.**

8

UNIT 2 REPORTING EVENTS

2.1

## Newspaper headlines

A newspaper headline says in a few words what the report below it is about. They generally use shortened, simplified sentences. For example, in English-language headlines, the verb to be, there is/are, and the articles a, an and the are usually left out. Also, they are often written in the simple present tense even when talking about the past or the future.

Look at the headlines below and try to work out the meaning of the underlined words.

![img-19.jpeg](img-19.jpeg)

Read how to work out the meaning of words. Then look at the underlined words again. Say which clue helped you understand them.

### Working out meanings

Remember to use these clues to help you work out the meanings of new works.

1 Synonyms - words with the same meaning
Example: The English lesson starts at 8:45; the History lesson commences at 9:45.
2 Antonyms - words with the opposite meaning
Example: Sue is always well dressed; Barry, however, always looks scruffy.
3 A definition or explanation
Example: Mona is a diligent, that is to say, a very hard-working pupil.
4 Examples or illustrations that show the meaning
Example: Tourists want to buy local artefacts, such as knives, pots and jewellery.
5 Cause and effect or result; if you understand the cause of something, you can work out the effect, and the other way around.
Example: Ali has had many accidents because he always drives recklessly.
6 Purpose - what something does
Example: I've just bought a telescope so that I can study the stars.
7 Word formation
Examples: - two known words make a new word: pain + killer = painkiller
- suffixes: hope + less = hopeless, dark + en = darken
- prefixes: un + well = unwell

Now do activities A and B in the Workbook.

9

2.2

## Today's news

On one page of some British newspapers, there is a summary of important reports in the rest of the newspaper.

Look quickly at the summary below and answer the questions as fast as you can. Write your answers in Workbook activity A.

# IN THE DAILY POST TODAY

# NEWS

# Roman dam found

A giant dam built by the Romans nearly 2,000 years ago has been discovered in the south of England.

Page 2

# Arctic ice scare

The arctic ice layer is half as thick as it was ten years ago, a scientist working at the North Pole said yesterday.

Page 5

# Heat wave victim recovers

American tourist Ed Shaw, who collapsed in the unusually hot weather a week ago, came out of hospital yesterday.

Page 3

# Castle to go

The old castle on the edge of the capital is to be demolished.

Page 10

# Fog crash

In Norton, two people were injured, one seriously, in a car crash in yesterday's fog.

Page 4

# 'Miracle' Rescue

Two swimmers were rescued from the sea during yesterday's storm. 'It's a miracle they were found,' a Rescue Services spokesman said. 'We can't explain it'.

Page 3

# Boxer marries sweetheart

Champion boxer Dick Turpin married his childhood sweetheart at a private ceremony last Saturday.

Page 2

![img-20.jpeg](img-20.jpeg)

# Wind Turbines Start Operation

These wind turbines on White Hill came into operation yesterday, providing power for over 600 homes.

# Many dead in crash

An Air International airplane crashed in thick forest in Central Russia last week

Front page

# Rare bird excitement

A black stork has been seen in this country for the first time in ten years. A large group of bird-watchers observed the rare bird at the weekend.

Page 2

1 On which page is there a story about:
a) a rescue? b) the Arctic? c) a wedding?
d) a bird? e) a plane? f) wind turbines?
2 Who said the rescue was a miracle?
3 What is the scare at the North Pole?
4 When was the marriage ceremony?
5 Why were the bird-watches excited?
6 Where did the plane crash?
7 How much power do the turbines provide?

Now do activities B and C in the Workbook.

10

# Don and Debbie: dreamers

2.4

Listen to the conversation. What does Jim think of Don's dream?

Do activities A and B in the Workbook.

Listen and repeat the conversation.

Show interest

Don: I had a dream last night. Well, a nightmare, actually.

Jim: Really! What about?

Ask for clarification

Don: It was awful. I was terrified. There were men with horrible faces and...

Jim: Just a minute. Calm down. Begin at the beginning. Now ... Where were you?

Set the scene

Don: I dreamt that we were working in the fields and ...

Jim: Who was? Who were you with?

Don: My brother. My elder brother. We were planting seed for next year. And I was driving the tractor. And it was brilliant weather. Then suddenly ...

Jim: Slow down. Slow down. What happened?

Tell the story

Don: I heard somebody shouting. Then I saw two men running towards us.

Ask for clarification

Jim: Who were they?

Don: I don't know. But they were really scary. One was holding a gun. My brother and I wanted to run but we couldn't move. It was terrible.

Jim: So how did you escape?

Don: I woke up.

Listen to the conversation. What does Jennie think of Debbie's dream?

Do activities C and D in the Workbook.

Listen and repeat the conversation.

Debbie: I had a brilliant dream last night. It was wonderful. I didn't want to wake up.

Jennie: Oh, no. Not again. Well, what was this one about?

Debbie: I dreamt that I was flying in a balloon. The moon was shining and the stars were ...

Jennie: Just a minute. You were flying in a balloon at night!

Debbie: Yes. It was beautiful. I was flying high above the clouds. And then suddenly ...

Jennie: You saw a spaceship.

Debbie: No. I heard a bird talking to me.

Jennie: You heard a bird talking to you!

Debbie: Yes. It told me to get out of the balloon and climb onto its back.

Jennie: And you got out, of course.

Debbie: Of course. We flew over the mountains and over the sea. I could see lots of small boats about a kilometre below me. It was wonderful. But then it ended.

Jennie: Why? What happened?

Debbie: I lost my hold on the bird's feathers and fell off.

Jennie: And how did you survive this one-kilometre fall?

Debbie: I woke up.

Ask questions about one of your partner's dreams and answer questions about one of your own.

11

--

2.5

# Language review 3

### *1 Use of the Passive*

You use the Passive when you want to make the thing done more important than the person who does it.

**Examples:** The doctors let Ed Shaw out of hospital. →
Ed Shaw **was let out** of hospital.
The police arrested a man for dangerous driving. →
A man **was arrested** for dangerous driving.

### *2 Use of the Past continuous*

You use the Past continuous when you want to set the scene for a story.

**Examples:** We were working in the fields (when something happened).
**Note:** Use the Past simple to say *what happened*, e.g. *I heard somebody*.

### *3 Sense verbs (hear, see, feel) followed by an object then a verb.*

You can use these structure to continue the scene-setting.

**Examples:** I heard somebody. He was shouting. →
I heard somebody shouting.

### *4 The verb to be + to + infinitive*

You can use these structure to talk about future plans or forecasts. You often see it in newspaper.

**Examples:** The President **is to meet** the ambassador tomorrow.
The thick fog **is to clear** this afternoon.

### *5 Punctuation*

In newspaper reports the writer uses a mixture of direct and reported speech for variety and interest.

These are called speech marks.
'It's a miracle they were found,' a Rescue Service spokesman said. 'We can't explain it.'
Note the comma here.

**Find other examples of the above language in the texts.**

**Now do activities A, B, and C in the Workbook.**

12

# Natural disasters

2.6

Here are some definitions of natural disasters. Match them with the pictures. Write your answers in Workbook activity A.

A very large wood is called a forest. A forest fire is very difficult to control because it spreads so quickly.
B A drought is a water shortage after a long period with no rain.
C When there is deep water over normally dry land, this is called a flood. When this happens very quickly, such as in a wadi in the mountains, it is called a flash flood.
D An epidemic is an illness that spreads quickly and affects many people.
E A volcano is a mountain with a hole in the top. Smoke rises out of the hole and liquid or molten rock flows. When the molten rock bursts out suddenly, this is called a volcanic eruption.
F A famine is a shortage of food. During a famine, people sometimes starve, they die of hunger.
G A hurricane is a powerful storm with strong winds.
H The hard rock surface of the earth is called the crust. The earth's crust is divided into several sections called plates. The place where two plates meet is called a fault line. Two plates moving along a fault line causes an earthquake. During an earthquake the ground moves and shakes.

![img-21.jpeg](img-21.jpeg)

Now do activities B and C in the Workbook.

13

A

2.7

## A newspaper report

Read the headlines and look at the photograph in this newspaper report. What do you expect to read about?

# HURRICANE HITS CENTRAL AMERICA

## Thousands dead

The worst hurricane in living memory has caused terrible damage and loss of life throughout Central America. In the large towns, nearly three-quarters of all buildings have been destroyed. In the countryside, whole villages, in which hundreds of people lived, have disappeared. Hundreds of thousands are homeless and 10,000 are feared dead.

The storm hit the area late on Tuesday evening, destroying everything in its path. Winds of over 240 kph demolished all the wooden houses and tore the roofs off others, including the country's main hospital. Cars and lorries were blown onto their sides. Whole banana plantations, on which thousands of people worked, were flattened. Electricity and telephone lines were cut. In the mountain areas, heavy rain caused flash floods and

![img-22.jpeg](img-22.jpeg)

Houses flattened by 240 kph winds

landslides. Roads and bridges, along which all supplies used to come, were swept away. Rivers of mud, up to five metres deep, swept down the mountainsides, covering several villages.

On Wednesday afternoon the full extent of the damage became clear. Crowds of people stood around silently, looking at the wrecks of the houses they used to live in. Many had lost relatives, their

homes and their jobs. Men, women and children cried helplessly. Rescue teams started work as soon as they could, but they can do little for most of the people. There are no tents and few medical supplies. The only way to deliver them is by helicopter and the army only has two.

The hurricane is now moving towards the south coast of the USA, but is getting weaker all the time.

Look at the last sentence. Imagine you live on the south coast of the USA. Think of a headline for a newspaper report on the same day.

Now do activities A to E in the Workbook.

14

![A small circular logo with a stylized 'A' inside.]()

# Language review 4

2.10

## 1 *Use of the Present perfect tense*

Use the Present perfect tense to describe the present situation.

**Example:** The worst hurricane in living memory **has caused** terrible damage.

## 2 *Use of the Past simple tense*

Use the Past simple tense to describe something that happened at a known time. Use adverbs to say when the event happened.

**Example:** The storm **hit** the area late on Tuesday evening.

## 3 *Prepositions in relative clauses*

- * Relative clauses giving necessary information

**Example:** The house is very old. I used to live in it.
The house **I used to live in** is very old.

**Note:** The preposition is at the end of the relative clause.

- * Relative clauses giving additional information.

**Example:** Sana'a Secondary School is one of the biggest schools in the country.
I went to it when I was younger.
Sana'a Secondary School, **to which I went when I was younger**,
is one of the biggest schools in the country.

**Note:** The preposition is at the beginning of the relative clause. The clause is written between commas.

## 4 *Adverbs and adverbial phrases*

These tell us more about actions.

**Examples:** (How) People stood around **silently**.
(Where) **In the countryside** whole villages have disappeared.
(When) The storm hit the area **late on Tuesday evening**.

**Find other examples of the above language points in the texts.**

**Now do activities A, B and C in the Workbook.**

15

2.11

# Armenia - 7, December 1988

Look at the photographs and read the newsflashes and information about the disaster.

![img-23.jpeg](img-23.jpeg)

**The Richter scale:** The strength of an earthquake is measured on the Richter scale. It was invented by Charles Richter, an American scientist.

|  Richter scale | Effects  |
| --- | --- |
|  More than 8.0 | Almost total damage  |
|  More than 7.4 | Great damage  |
|  7.0 - 7.3 | Serious damage, metal bridges bent  |
|  6.2 - 6.9 | Considerable damage to buildings  |
|  5.5 - 6.1 | Slight damage to buildings  |

Think about the best order for the information.

Now do activities A, B and C in the Workbook before writing your own report.

16

UNIT 3 LOOKING FOR A JOB

3.1

## Getting work experience

Pupils in their last year at school are often not sure what they want to do after they have left. Some companies and organizations try to help young people by offering them 'work experience' - the chance to find out about different jobs by working at the weekends or in the school holidays.

Look back to page 9 and read again how to work out the meaning of words. Then find the meaning of the underlined words in the notices below.

# WORK EXPERIENCE OPPORTUNITIES

WEO 8

Would you like to learn how a large office is run? The Ministry of Health is offering somebody the chance to experience work in the Administration Department and learn about office organization. There are long-term career opportunities for the successful applicant.

WEO 5

Because of the increase in the number of TV programmes for schools, there are many vacancies in the City TV station. This is a WEO for somebody who is interested in news, theatre and music. If you take up a permanent position, you will receive an excellent salary. We believe in paying people well.

WEO 2

The Central Hospital is looking for a boy or girl with a knowledge of first-aid. The experience will help you get the qualifications needed to become a nurse or even a doctor. Ask your school office for an application form, fill it in and send it to the hospital.

WEO 7

Would you like to help the Society for the Handicapped organize trips for its members? You will take the members on trips yourself, so a driving licence is required. No experience is necessary and full training will be given in the special needs of the handicapped. This opportunity is for someone interested in social work.

WEO 6

The Ministry of the Environment is offering you the chance to save the coast of our country. You must be willing to work in all kinds of weather. A knowledge of plants would be an advantage.

WEO 3

If you are interested in working in business, this is a great opportunity. The Tiger Ice-Cream Company is looking for a young man who wants to learn about sales and marketing. At first your duties will include delivering ice-cream to hospital, hotels and restaurants. It is important for us that we choose the right young man, so he must attend an interview at our factory.

Now do activities A to E in the Workbook.

17

3.3

## Thinking about the future

Read about six people in their last year at school. What are they good at? What are their interests? What are they like? Fill in the table in Workbook activity A.

![img-24.jpeg](img-24.jpeg)

Patrick's ambition after leaving school is to become a doctor. However, he is not very good at Chemistry or Biology. His best subject is Mathematics. For the past year he has been going to evening classes in first-aid. He is adventurous and when he can, he goes underwater swimming.

![img-25.jpeg](img-25.jpeg)

Diana is very efficient and likes organizing things. Since the beginning of the year she has been planning all the class trips and activities. She writes all the letters and notices on her computer. Her best subject is English, but she enjoys Mathematics more.

At the weekend she goes sailing and she is the secretary of the local sailing club. She would like to go into Government Administration.

![img-26.jpeg](img-26.jpeg)

Andrew is not very good at any subjects at school although he will probably pass his final examinations. He has a driving licence and every weekend he drives out into the country and then walks for hours. He is very interested in nature and has been

reading about trees, plants and flowers for almost two years. He would like to work in the country. He is very hard-working and gets on well with people.

![img-27.jpeg](img-27.jpeg)

Justin has two very different hobbies: driving his four-wheel-drive car in the country, and cooking. He spends most Saturdays driving along muddy roads. On Sundays he cooks all the meals for the whole family. He has been doing this since he was 12. His best

subjects are Mathematics and Sport. Both his parents are teachers, but he would like to go into business.

![img-28.jpeg](img-28.jpeg)

Clare has been collecting folk music CDs for three years. She now has 150. She has lots of friends and she likes playing her music in them. One day she would like to work in radio or television. At school her best subjects are History and Music. She has a good

speaking voice and often acts in the plays put on by the school drama group.

![img-29.jpeg](img-29.jpeg)

Fareeda is a very helpful young woman and is very popular with the others in her class. She has been driving for six months and at the weekend she takes old people shopping in her parents' car. At school she is excellent at History, but she does not want to go to

college. She wants to help other people in some way, perhaps as social worker.

Match the six people with the work experience opportunities described on page 17.

Now do activity B in the Workbook.

18

# Getting careers advice

3.4

Many schools have Career Advisors to help school-leavers plan their careers.

**Listen to how the school-leaver speaks. How does he feel? Answer the questions in Workbook activities A and B. Listen and repeat the conversation.**

Offer Help
ask for advice

**Career Advisor:** Now, how can I help you?
**School-leaver:** Well, it's just that ... I don't know ... I need your advice. I've no idea what I want to do after I leave school. I've been thinking about it but ...

Ask about family

**Career Advisor:** What do your parents do?
**School-leaver:** My father's an engineer and my mother's a Maths teacher.

Give advice

**Career Advisor:** Then why not train to be a Maths teacher?

Turn down advice

**School-leaver:** I'm no good at Maths. I'm hopeless at it.

**Career Advisor:** What are you good at?

**School-leaver:** Um... History... and Geography ... and ... that's it.

Talk about recent
experience

**Career Advisor:** What work experience have you had?
**School-leaver:** Well, recently I've been working at the hospital.

**Career Advisor:** And do you enjoy it?

**School-leaver:** Yes, very much.

Give advice

**Career Advisor:** If I were you, I would...

![img-30.jpeg](img-30.jpeg)

**Make your own conversation using the sentences below.**

ASKING FOR ADVICE

Can you help me, please?

I need some advice on what to do after school.

I don't know what to do. Can you advise me?

ACCEPTING ADVICE

That's a good idea.

That's a very good piece of advice.

I'll do that.

GIVING ADVICE

If I were you, I would...

If I were in your shoes, I would study Medicine.

Why not/don't you...

The best thing for you to do would be to...

TURNING DOWN ADVICE

That's not a very good idea.

I don't like doing that.

I'm not good/very bad at that.

19

3.5

# Language review 5

### 1 *The Present perfect continuous*

We use this tense to:

1 talk about the present effects of something that happened over a period of time in the recent past.
2 talk about a continuous action that started in the past, continued up to now and may be continuing now.
3 show that something has been changing or developing over a period of time and has been happening regularly.

**Examples:** He has been playing football. (That's why his clothes are dirty.)
It has been raining. (That's why the clothes are wet.)
Mona has been studying English for six years. (And she is still studying English.)
The weather has been getting warmer recently.

Compare the Present perfect simple and the Present perfect continuous tenses.

The simple tense

- emphasizes the completion of the action
- can refer to actions that happened a long time ago

**Examples:**

I've done my homework.
I've read that book.

The continuous tense

- emphasizes how long the action has been going on
- usually refers to something that has been happening recently

**Examples:**

I've been doing my homework for hours.
I've been reading that book.
(just now)

- Both tenses can be used to describe actions that started in the past and are still continuing.

**Examples:** I have lived here for six years. (Perhaps the speaker will not continue living there.)
I have been living here since 1994. (The speaker will probably go on living here.)

- The following verbs are not used with the continuous tense:
be, have (=own), believe, know, need, like, love, prefer

### 2 *Verb + infinitive or + -ing form*

The verbs may be followed either by the infinitive or the -ing form:
begin, continue, start, like, love, prefer, hate

**Examples:** It began to rain / began raining. I (don't) like to sail / like sailing.
Note: When would is used in front of like, love, prefer, hate, you must use to + infinitive.

Now do activities A, B, and C in the Workbook.

20

# Job and qualities

3.6

## Names of jobs

Some names of jobs describe what the person does very clearly. For example, taxi-driver.
The two nouns combine to make one word and are called compounds.

Sometimes they are joined: shopkeeper

Sometimes they have a hyphen: life-guard

Sometimes they stay as two words: English teacher

### Say what each of these people does in their job:

Example: taxi-driver: A taxi-driver dives taxis.

Note: In American English programme is always spelt 'program'. In British English this spelling is used only in connection with computers. It is both a noun and a verb.

tourist guide firefighter bookseller taxi-driver
computer programmer dressmaker film director newsreader
science teacher bank manager project manager

In 'taxi-driver' there is no 's' at the end of taxi. When nouns are used as adjectives, They are always singular.

### Find other examples in the list. Can you think of any others?

## Qualities

If you want to be a teacher you must be patient. In an advertisement the employer will ask for someone who shows patience.

### Use the adjectives and nouns below to make sentences about other jobs.

polite politeness
diligent diligence
friendly friendliness
able ability

patient patience
conscientious conscientiousness
confident confidence
computer literate computer literacy

### What do you think these underlined phrases mean?

Applicants will have good people skills.

The successful candidate will have a telephone manner.

Good keyboard skills are essential.

All our sales people have good communication skills.

### You need to be able to do different things in different jobs. In which jobs should you or must you...

be able to...

... use a computer?

... speak a foreign language?

Note: good/bad at doing something

be good at...

... dealing with people?

... explaining things to people?

be willing to...

... work long and irregular hours?

... travel?

### Now do activities A, B and C in the Workbook.

21

SOM

--

3.8

## Applying for a job

Read this job advertisement and think about the job requirements. Then do activities A and B in the Workbook.

### ADULT EDUCATION DEVELOPMENT WORKER

The Ministry of Education is looking for a confident and well-educated individual to work locally in their adult education programme. The post involves teaching adults with learning difficulties in their own homes, so a driving licence is desirable. The successful applicants will have good communication skills, experience of teaching and be computer literate.

Age range: 21-25

Starting salary: £18,000-£19,500 pa according to experience

Apply in writing to: Mrs Jill Castle • PO Box 0086 • London S9 3QK

Now read the letters of application below. How well do the applicants fit the requirements of the job?

17 Wood Road
Manchester M29 4TF

Mrs Jill Castle
PO Box 0086
London S9 3QK

March 18

Dear Mrs Castle

I am interested in applying for the teaching post advertisement in today's Daily News.

I am 24 years old and am a qualified Primary School teacher. I have taught since I was 21 and have worked in different parts of the country. I have also had training in adult education and for the past six months I have been doing evening classes for adults with learning difficulties. I have been using computers in this work. Furthermore I have recently passed the driving test. My present salary is £15,000 per annum.

I look forward to hearing from you in the near future and would you be grateful for the chance of attending an interview.

Yours sincerely,

Kate Ash (Miss)

140 Tower Road
Liverpool L9 9QZ

Mrs Jill Castle
PO Box 0086
London S9 3QK
March 20

Dear Mrs. Castle

I am writing to apply for the job of teacher as advertised in the Daily News of March 18.

I am 23 years old and have been working in adult education for two years. As a result, I have had a lot of experience in this field. I have had a full driving licence for three years. Although I have no experience of working on computers, I am very willing to learn. At the moment I am earning £21,000 a year.

I look forward to hearing from you.
Yours sincerely,

Tim Brook

Now do activity C in the Workbook.

22

# Language review 6

3.10

## 1 Nouns, adjectives and verbs + prepositions

Some adjectives, nouns and verbs are commonly followed by prepositions.
These are the ones you have seen in Unit 3:

|  *Nouns* | *Adjectives* | *Verbs*  |
| --- | --- | --- |
|  training in experience of chance of | interested in grateful for | look forward to applying for  |

**Examples:** I would like to **apply for** the job.
I have **experience of** working with children.
**Note:** They are always followed by either a noun or a gerund (the *-ing* form).

## 2 Addition

Addition, here, means giving information. To do this, we use connecting words,

- inside a sentence,
- at the end of a sentence,
- at the beginning of a sentence.

**Examples:** He wore a hat and a coat **as well as/together with** woollen gloves.
He wore a hat and a coat. He put on woollen gloves **as well/also**.
She is polite and friendly. **Furthermore**, she is very conscientious.
**In addition,**
**Another reason** for giving her the job is her patience.

**Note:** *also* can be used inside a sentence. He **also** put on woollen gloves.

## 3 Consequence

Consequence is about one idea being the result of another.
The expressions used to connect the ideas are as follows:

because so therefore
thus (followed by the word ending *-ing*)
consequently as a consequence
as a result accordingly that is why

**Find examples of this language in the texts.**

**Now do activities A, B and C in the Workbook.**

23

3.11 3.12

# A business letter

![img-31.jpeg](img-31.jpeg)

- A The sender's address
- B The name and address of the receiver
- C The sender's signature
- D The greeting, e.g. Dear Sir
- E The close, e.g. Yours faithfully
- F Information about the sender
- G A reference to the advertisement
- H The sender's name typed or printed
- I The date
- J Asking for an interview

This diagram shows the layout of a good formal letter. It is an application for a job that was advertised in a newspaper.

Match the boxes with the correct descriptions in the list below the letter. Write your answers in Workbook activity A.

Note: If you use the greeting Dear Sir, or Dear Madam, you must use Yours faithfully, to close.
If you use the greeting Dear Mr/Mrs Jones, for example, you must use Yours sincerely, to close.

Write a business letter in answer to this job advertisement in the Daily News of April 20th.

# Fantastic Job Opportunity!

Have you ever wanted to work on a newspaper?
We are looking for young men and women to train as reporters and photographers for a new general interest magazine for people under 25.

No experience is necessary but the successful applicants must be willing to work hard and already have a wide range of interests.

Write and tell us all about yourself and why you think we should give you the chance to join our exciting team.

Write to: The Editor, The Daily News, PO Box 0055, London S18 9HP

Now do activity B in the Workbook.

When writing a letter of application, you must sell yourself, that is, you must give as much interesting information about yourself as you can.

Answer these questions:

- Which school subjects do you like most? Why?
- What interests or hobbies do you have? Give details. If you like music, say which music and why; if you play sport, say which sport and why.
- Have you ever had any work experience? What was it?
- Have you done anything connected with the job itself? What was it?

- Have you travelled? Where to, when and why?
- Do you have any ambitions? What are they?

Remember!

- Lay out your letter correctly.
- Refer to the advertisement.
- Ask for an interview.
- Keep the letter short, but do not miss out anything important.
- Use the correct form of address.

24

UNIT 4 TABLES, FLOW CHARTS AND DIAGRAMS

# Food

4.1

Here are some words connected with food and its preparation.
Match them with the pictures in Workbook activity A.

Things grown in Yemen

A dates B figs C mangoes D papayas E sorghum F apricots G grapes H pears

![img-32.jpeg](img-32.jpeg)

Answer these questions:

1 What grows in the mountains?
2 What grows on trees?
3 What is a grain crop?

Things we do when we prepare and cook food

I boil J squeeze K peel L crush M grate N chop O grill P grind

![img-33.jpeg](img-33.jpeg)

Answer these questions:

1 Can you peel a fig?
2 Can you grind sorghum?
3 What do you get if you squeeze a lemon?
4 In what ways do you generally:
- prepare vegetables?
- turn fruit into a drink?

Now do activity B in the Workbook.

25

4.3

## Learning to cook

James is interested in learning to cook. His mother teaches him how to make a fish curry.

**Listen to the conversation. Answer the questions in Workbook activity A. Listen and repeat the conversation.**

![img-34.jpeg](img-34.jpeg)

![img-35.jpeg](img-35.jpeg)

Ask about it

Name ingu

![img-36.jpeg](img-36.jpeg)

Ask about it

Describe me

![img-37.jpeg](img-37.jpeg)

**James:** What are you doing, mum?  
 **Mother:** I'm making a fish curry.  
 **James:** That sounds good. And these are the ingredients?  
 **Mother:** Yes, I always prepare them before I start cooking.  
 **James:** So... that's the fish ... and the tomatoes and onions ... and that's garlic, isn't it?  
 **Mother:** Yes. Two peeled and chopped tomatoes, two chopped onions, and three crushed cloves of garlic.  
 **James:** What's that round, brown thing?  
 **Mother:** It's a *loomi* - a small, dried lime.  
 **James:** And those other things... they're spices, I suppose.  
 **Mother:** Yes, two teaspoons of *baharat* - that's a mixture of spices. And ... half a teaspoon of turmeric, half a teaspoon of chilli powder and a quarter of a teaspoon of ground ginger.  
 **James:** What's in this bowl?  
 **Mother:** Lemon juice... about one teaspoon.  
 **James:** Anything else?  
 **Mother:** Oil for frying, and, of course, salt and pepper.  
 **James:** So those are the ingredients. How do you actually cook the curry, then?  
 **Mother:** First you fry the onions and garlic. Then you add the spices and fry for a further two minutes. Next you add the tomatoes, *loomi*, lemon juice, salt and pepper. After that, you cover the mixture with water and simmer for fifteen minutes.  
 **James:** What about the fish?  
 **Mother:** While the mixture is boiling gently, you fry the pieces of fish.  
 **James:** How long for?  
 **Mother:** Until they are golden brown. Then you put the fish into the sauce and simmer for a further fifteen minutes... and that's it... fish curry. Simple, isn't it?

![img-38.jpeg](img-38.jpeg)

![img-39.jpeg](img-39.jpeg)

![img-40.jpeg](img-40.jpeg)

**Now do activities B and C in the Workbook.**

26

# Agriculture in Yemen

Information presented in a written passage can sometimes be shortened and presented in the form of a table. It is easier and quicker to find information using a table.

Scan these five paragraphs about agriculture in Northern Yemen. What type of information is in each paragraph? Would the information be easier to understand in table form?

The climate in the Northern part of Yemen can be divided into five areas or zones. In the Tihamah on the Red Sea (sea level to 300m) the climate is tropical. The air is hot and humid in the summer and pleasantly warm in the winter. Dates and cotton grow well here, as do vegetables and grains, which are both a winter and summer crop.

Further up the Western mountain slopes, in Zone 2 (300 - 2,200m), the climate becomes subtropical, then moderate. Fruit typical of this area are mangoes, papayas and bananas. The highest parts of the slopes have a moderate climate with rather cold winter nights. It is here that Yemen's most famous crop, coffee, is grown.

The Central Highlands (2,200-3,700m) also have a moderate climate. All kinds of grain crops, such as sorghum, are grown on the mountain terraces. Many types of fruit are found here, including apricots, peaches and figs. In the more protected wadi beds, where there is also more water, apples, pears, oranges, lemons and grapes are grown. Yemen has more than twenty different types of grape, some seedless, each of a different colour.

![img-41.jpeg](img-41.jpeg)

On the Eastern mountain slopes (2,300 -1,100m), the climate again becomes subtropical. There is much less rainfall than in the Highlands and farming takes place mostly in the wadis. In these wadis, which lead to the desert, grapes and some fruit trees can be found. In the lower areas close to the Ruba' Al Khali, there are date and palm trees.

Further east in the yellow sands of the desert (1,000m), very little grows. For a short time after the rains, a little grass may appear. Apart from this and a few shrubs, there is no other vegetation.

Read this text again carefully and transfer the information to the table in Workbook activity A.

Now do activities B and C in the Workbook.

27

4.6

# Language review 7

### 1 *Use of sequence words and phrases (first, then, next, after that, finally)*

You use these words to introduce each stage of a process.

|  **Examples:** | **First** you fry the onions and garlic. **Then** you add the spices. **Next** you add the tomatoes. **After that** you cover the mixture. **Finally** you simmer for fifteen minutes.  |
| --- | --- |
|  **Note:** | some writers put a comma after each of these sequence words/phrases.  |
|  **Example:** | **First**, put some water in a pan.  |

### 2 *Use of the Passive*

You use the Passive when you want to make the object more important than the subject.

|  **Example:** | **subject** People | **object** grow coffee in Yemen. → Coffee is **grown** in Yemen.  |
| --- | --- | --- |
|   | **subject** We can find | **object** fruit trees in some wadis. → Fruit trees **can be found** in some wadis  |

**Note:** We often omit the original subject in the passive sentence, particularly when it is not important, as in the above examples 'people' and 'we'.

### 3 *Use of while + Present continuous with Present simple*

You use *while* + Present continuous with the Present simple when you want to show that two actions happen at the same time.

|  **Example:** | **First action** | **Second action**  |
| --- | --- | --- |
|   | While the mixture is boiling gently, you fry the pieces of fish.  |   |

**Find examples of the above language in the texts.**
**Now do activities A to D in the Workbook.**

28

# Words and more words

4.7

Read this extract from a reference book about the English language and do Workbook activity A.

New words are coming into the English language almost every day. Where do these new words come from?

One way of creating new words to borrow or take them from other languages. English has been taking words from Latin, Greek and French for hundreds of years. French, for example, has given us some very common words, such as table, dinner and medicine. But English has borrowed from many other languages also; the list is endless.

![img-42.jpeg](img-42.jpeg)

Kayak, a kind of boat, and igloo, a house made of snow, come directly from the Eskimo language because these two objects are found only among the Eskimos, who live in the icy cold of the Arctic. Many years ago contact or meetings with Arab mathematicians brought the Arabic words algebra and zero into English. Trade with the Arab world has given English words like sugar, cotton and coffee.

Another way of forming new words is to add a prefix or suffix to the stem of a word that already exists. The stem of a word is the part that is common to all forms of that word, such as walk, walk (ing), walk(ed). A prefix is a group of letters that goes in front of the stem. Some common examples of prefixes are re-(remake), un-(unhappy) and mis-(misunderstand). A suffix is added to the end of a word. Examples are -able (comfortable) and -less (careless). A prefix usually changes the meaning of a word. A suffix usually changes the word into a different part of speech.

A third way of making new words is to combine or join together two different words to make another word. The words blue and berry can be combined to get the word blueberry. There are many berries that are blue in colour, but there is only one berry that is known as a blueberry. Other examples of words joined together are farmhouse,

handbag and newspaper. Sometimes the combined word, which is called a compound, has a hyphen in it, as in air-conditioner. Sometimes it is written as two words, as in seat belt, cassette recorder and word processor.

![img-43.jpeg](img-43.jpeg)

A fourth method of creating new words is to change the way a word is used. For example, a noun can be used as a verb, so that as well as buying some milk (noun) we can milk (verb) a cow. Other parts of speech can also be converted or changed. For example,

![img-44.jpeg](img-44.jpeg)

an adjective can be used as a noun, as when a spare wheel is called a spare. Prepositions are sometimes used as verbs, as in to up the price which, of course, means to raise or increase the price.

Now do activities B to F in the Workbook.

29

M

4.8

## Investigating the world around us

Aisha Yousif was asked to design a simple experiment on water pressure. She carried out an experiment in the school laboratory and wrote up her results.

**Read through the experiment. What did Aisha want to prove? Did she succeed?**

**Name:** Aisha Yousif

**Date:** 11.12.1999

**TITLE:** An investigation into water pressure.

**QUESTION:** Why is a dam thicker at the bottom than at the top?

**RESEARCH:** When you dive under water, the further you go down, the more your ears hurt.

**HYPOTHESIS:** The deeper the water, the greater the pressure.

**MATERIALS:** One 2-litre plastic bottle, a tray or basin, a nail, water and pair of scissors.

1. Cut the top off the plastic bottle.
2. Use a nail to make four holes in the bottle at different levels from top to bottom.
3. Put the bottle in the tray or basin.
4. Cover the holes with your fingers, and then have a friend fill the bottle with water.
5. When the bottle is full, take your fingers away from the holes and study the flow of water.

**DATA:** Four jets of water came out of the bottle. The jet at the top was the shortest and the jet at the bottom was the longest. The other two jets were in-between.

**CONCLUSION:** The length of the jet is related to the pressure of the water - the greater the pressure, the longer the jet. The longest jet is at the greatest depth. The data therefore confirms the hypothesis.

![img-45.jpeg](img-45.jpeg)

Now do activities A and B in the Workbook.

30

# Language review 8

4.10

## 1 Use of have/get + infinitive

You use these verbs to replace other instruction words such as ask, tell or order.
Using have or get focuses on the instruction itself rather than the way it is given.

|  Example: | Ask the boy to put away his bag. Have the boy put away his bag. Get the boy to put away his bag.  |
| --- | --- |
|  Note: | With have, the infinitive is without to.  |

## 2 Use of get to show change of state

Get is commonly used to replace the more formal become.

Example: He got wet when he went out in the boat.

## 3 Use of two comparatives

You use a comparative in each half of a sentence to show how one action causes the other or is related to the other.

Examples: The deeper the water, the greater the pressure.

The further you go down, the more your ears hurt.

Note: These kinds of sentences are often different from simple comparative sentences.

For example, words omitted and word order change. In the first example, words are omitted-in fact, there is no active verb:

The deeper (that) the water (becomes), the greater (that) the pressure (becomes).

In the second example there are omitted words and a change in word order. Notice also that the comparative words further, more have become nouns the further, the more:

(As) you go down further, your ears hurt more.

## 4 Parts of speech (nouns, verbs, adjectives, adverbs, prepositions)

It is important to identify what part of speech a word is in a sentence. This helps you guess the meaning of the word if it is new.

|  Example: | adverb | verb | preposition | adjective | noun  |
| --- | --- | --- | --- | --- | --- |
|   | Carefully | cut | the top | off | the plastic bottle.  |

Many words can be different parts of speech. Sometimes the meaning is related, sometimes it is completely different.

|  Examples: | water | noun | = liquid  |
| --- | --- | --- | --- |
|   |   |  verb | = give water to  |
|   |  up | preposition | = movement upwards  |
|   |   |  verb | = raise  |
|   |  well | noun | = hole which you can get water from  |
|   |   |  adjective | = not ill  |
|   |   |  adverb | = in a good way  |

Find other examples of the above language points in the texts.
Now do activities A to D in the Workbook.

31

WOM

4.11 4.12

# Frozen peas

Read this description of the way peas are frozen.
Then do activities A and B in the Workbook.

![img-46.jpeg](img-46.jpeg)

Frozen peas are fresher than the peas you buy in the market or in a shop. This is because frozen peas are processed within two or three hours of being picked or harvested. Ordinary peas are first sent to the market and then on to shops. This can take many hours or even days. All this time the peas are getting less and less fresh.

For top quality, peas must be processed as quickly as possible, the quicker the better. On arrival at the processing factory, the softer peas are chosen for freezing and the harder peas kept for canning. The peas are quickly cleaned by fans and then thoroughly washed. Next the peas are passed through boiling water for one minute, or through steam for two or three minutes, a process known as blanching. After that they are cooled to less than 20°C and passed through salt water or brine. They are then washed again in clean water. Finally they are quick-frozen. The whole process takes about half an hour.

The frozen peas are packed into big bags and put into cold storage at -18°C. They may be stored for weeks or even months before being removed. They are then re-packed into smaller bags and sent in refrigerated trucks to shops and supermarkets.

Use this information to fill in the flow chart in Workbook activity C.

32

UNIT 5 WORKING THINGS OUT

5.1

## Word sets

Look at these words. What do they have in common?

table sofa chair armchair

Answer: They are all pieces of furniture.

A group of connected words is called a **word set**. The name of this set is *furniture*. Learning words as a set is one way of helping you remember them. The picture on this page illustrates words connected with travelling by sea.

In Workbook activity A, match the words below with the numbers in the pictures.

mast pulling up the sail rowing deck cabin horizon climbing aboard bow
oar telescope fishing boat tanker stern net

![img-47.jpeg](img-47.jpeg)

Look at the sentences below. Mark them true or false in Workbook activity B.

- A There is a large tanker on the horizon.
- B There is one sailor in the cabin.
- C The fishing boat has three masts.
- D There are some fish on the deck.
- E Some sailors are pulling up the flag.
- F Some sailor with the telescope is standing in the stern of the boat.
- G Three sailors are climbing aboard the fishing boat.
- H One man has lost an oar.
- I Some people are rowing away from the fishing boat.

Now do activities C and D in the Workbook.

33

5.2

# Possibilities

Three children are looking at something that they have found.
They are trying to work out what it is.

Look at what they are saying.

![img-48.jpeg](img-48.jpeg)

Talk about what these objects might be.

![img-49.jpeg](img-49.jpeg)

Discuss the possibilities.

What would happen if ...

1 ... there was no more rain in Yemen?
2 ... all planes stopped flying?
3 ... all plants stopped growing?
4 ... there was no more electricity?

I've no idea.
I haven't a clue.

![img-50.jpeg](img-50.jpeg)

![img-51.jpeg](img-51.jpeg)

If there was no more rain in
Yemen, the whole country
would turn to desert.

![img-52.jpeg](img-52.jpeg)

![img-53.jpeg](img-53.jpeg)

![img-54.jpeg](img-54.jpeg)

![img-55.jpeg](img-55.jpeg)

![img-56.jpeg](img-56.jpeg)

![img-57.jpeg](img-57.jpeg)

![img-58.jpeg](img-58.jpeg)

34

Now do activities A, B and C in the Workbook.

# Puzzles and riddles

5.4

Understanding some reading tests is like solving a puzzle. Things are not always stated or described directly. The reader has to infer what the writer is talking about.

**Read the puzzles below and work out what the answers might be. Activities A, B and C in the Workbook will help you think.**

**A More than one possible answer:**

*What is it?*

1 His day's work was over. He sat down and looked at the object on the table. He smiled, picked it up and put it to his mouth.
2 He was walking along the beach when suddenly he saw it lying on the sand. He went over and had a good look at it. 'I can use this,' he said to himself. He picked it up carefully and took it home.

![img-59.jpeg](img-59.jpeg)

Where are they?

1 He turned to the man in the seat next to him. 'What time do we leave?' he asked. 'Any minute now,' was the reply. Just then he heard the engine start. 'You're right,' he said.
2 I'm in a large room. People are talking quietly. Somebody comes into the room. Everybody stops chatting. The person starts speaking in a loud voice.

**B Only one possible answer.**

*Who says the following in their job?*

1 'As you can see, the inside of the building is decorated in the Chinese style.'
2 'I'm afraid we couldn't save the house because there wasn't enough water.'
3 'Can anybody tell me the name of the highest mountain in Africa?'
4 These peas will be ready for picking in about three days.
5 'How long do you wish to remain in the country, sir?'

*What objects might say something like this?*

1 'People kick me all the time but it doesn't worry me. It makes them happy, especially when they put me in the net.'
2 'People keep me in a safe place and use me when they want to buy things. I have a different name in most countries.'
3 'Without me you have to do your Mathematics homework in your head or on paper.'
4 'North, south, east or west - I'll show you where they are.'
5 'Hold me, jump off a mountain and fly like a bird.'

*What do these people feel? Why?*

1 He paced up and down the waiting room in the hospital.

![img-60.jpeg](img-60.jpeg)

2 She covered her face when she heard the news.

**Now do activity D in the Workbook.**

35

5.5

# Language review 9

### 1 *Modal verbs - 1*

Modal verbs are not used on their own. They are used with other verbs to express different meanings.

- Degrees of possibility

You are not certain.

**Example:** It may (not)/might (not) could be a toothbrush.

You are certain.

**Examples:** (Positive) I must be a toothbrush.
(Negative) I can't be a toothbrush.

**Note:** *Must not (mustn't)* can only be used when you want to tell somebody that they are not allowed to do something.

**Example:** You must not look at your books during an exam.

- Ability
  *can/cannot* refers to the present
  *could (not)* is used
  - to refer to the past
  - after *wish*
  - in conditional sentences

**Examples:** I can /cannot swim.
I could (not) swim when I was six.
I wish I could swim.
If I lived near the sea, I could learn to swim.

**Note:** You can use **be able to** instead of **can**.

**Examples:** I am able to swim.
I wish I was able to swim.

### 2 *'Sense' verbs + object + verb*

Some sense verbs are followed by the *-ing* form. This emphasizes the action as continuous and is often used for setting the scene (see Language review 4). When followed by the infinitive, this emphasizes that the action is completed.

**Example:** I saw/heard/watched the goats come down the street.
(And later told the farmer what I saw/heard, etc.)
I saw/heard/watched the goats coming down the street.
(And tried to stop them coming into the garden.)

**Find examples of this language in the texts.**

**Now do activities A and B in the Workbook.**

36

# The mystery of the Mary Celeste

What is the mystery? Read the article and find out.

![img-61.jpeg](img-61.jpeg)

from New York to Gibraltar. There was a good wind and visibility was excellent. The captain could see at least five kilometres in every direction. At about 9 o'clock one of the sailors sighted another ship on the horizon.

Two hours later the two ships were much closer to each other. Captain Morehouse put his telescope to his eye and looked at the other ship. There was something strange about the way she was moving. As the wind turned, the ship turned. The Captain ordered one of his crew to put up signal flags, greeting the other ship and asking for her destination. There was no answer. Some time later he looked through his telescope again. Now he could just make out the name of the ship: Mary Celeste. But then his blood ran cold. There was nobody on the deck of the ship, nobody climbing the masts and nobody at the wheel. The Mary Celeste was steering herself.

When the two ships were about 100 metres apart, Captain Morehouse and two of his crew rowed across to the Mary Celeste. He and one of the men climbed aboard. They went below

Sailors coming back from long voyages used to tell stories of lost cities, strange animals and boiling oceans. Most of these strange stories have been explained; others have stayed mysteries. The true story of the Mary Celeste is perhaps the most famous unexplained mystery of the sea.

On the morning of December 5th, 1872, Captain Morehouse, the Captain of the ship Dei Gratia, and his crew were sailing across the Atlantic Ocean

deck and looked in every cabin. They found nobody. The ship was completely deserted.

As they searched the mysterious ship, Captain Morehouse and the sailor became more and more puzzled by what they saw. In the crew's cabins, everything had been put away tidily, and in the kitchen, pans half-full of food were hanging over a dead fire. In the largest cabin, where the captain had lived with his family, there was a half-eaten meal on the table. On a sewing machine in one corner lay a child's dress, which somebody had been repairing. In a small cupboard Captain Morehouse found gold, jewellery and money. Nothing had been taken and there was no sign of panic or trouble. It seemed as if the crew and the passengers had decided at the same time to throw themselves into the sea.

Captain Morehouse and the sailor then found two unusual things. First they found a sword stained with what looked like blood. They thought the crew must have mutinied and killed the captain. However, all the ship's boats were still hanging in their correct places; the crew could not have left the ship that way. At the bow they found another mystery. Two pieces of wood, each about two metres long, had been cut out of the rail on both sides of the ship.

None of the people from the Mary Celeste was ever seen again. The strange story of the deserted ship found drifting on the open sea has never been explained.

Now do activities A, B and C in the Workbook.

37

S

5.6

5.7

## What could have happened?

Since the *Mary Celeste* was found, many people have tried to explain the mystery. Do you believe any of the explanations? If not, why not?

![img-62.jpeg](img-62.jpeg)

1 A huge monster may have come up out of the sea and dragged all the people into the water.

![img-63.jpeg](img-63.jpeg)

2 An island might have appeared suddenly out of the ocean and everybody got off the ship to walk on the new land. But then, just as suddenly, the island must have sunk back into the sea and everybody must have drowned.

3 A hurricane could have blown everybody off the ship.

![img-64.jpeg](img-64.jpeg)

4 The passengers and crew might have caught a terrible disease and decided to drown themselves.

5 Pirates may have attacked the ship and taken all the crew and passengers. Then the pirates could have sold them as slave

![img-65.jpeg](img-65.jpeg)

![img-66.jpeg](img-66.jpeg)

38

Now do activities A and C in the Workbook.

# Language review 10

5.9

## 1 Modal verbs - 2

There are different ways of talking about how something happened in the past.

Suggesting a possible explanation-may/might/could+ have+ past participle
Deciding on an explanation - must + have + past participle
Not accepting the suggestion or decision - cannot/could not + have + past participle
Giving reasons for (not) accepting a suggestion or decision - because

|  Examples: | The sailors may/might/could have mutinied. The sailors must have mutinied. The sailors cannot/could not have mutinied. The sailors of the Mary Celeste may (not) have mutinied because Captain Morehouse found a sword stained with blood.  |
| --- | --- |

## 2 Verb + object + infinitive with to

This is a very common sentence pattern, used with many verbs.

|  Examples: | He ordered his crew to put up signal flags. The teacher wants us to work harder. I would like you to come home early. My mother asked me to help her.  |
| --- | --- |

## 3 Reflexive pronouns

The reflexive pronoun is used when the subject of a verb is also the object.

|  Singular | Plural  |
| --- | --- |
|  myself | ourselves  |
|  yourself | yourselves  |
|  himself | themselves  |
|  herself |   |
|  itself |   |
|  Example: The passengers decided to drown themselves.  |   |

Find examples of this language in the texts.

Now do activities A, B and C in the Workbook.

39

WOM

5.11 5.12

# Tracks in the sand

![img-67.jpeg](img-67.jpeg)

Read the short introduction and look at the pictures. They tell the beginning of a story. Workbook activities A to C in lessons 5.11 and 5.12 will help you write the story 'Tracks in the Sand'.

Hamad Faisal and Tim Brook work for the National Oil Company. They often fly across the desert to the oil-fields. One afternoon...

Hamad Faisal and Tim Brook

![img-68.jpeg](img-68.jpeg)

![img-69.jpeg](img-69.jpeg)

![img-70.jpeg](img-70.jpeg)

![img-71.jpeg](img-71.jpeg)

![img-72.jpeg](img-72.jpeg)

The nearest road is 25 kilometres away! Come on!

40

UNIT 6 LOOKING BACK

# Emergencies in the news

6.1

Read the newspaper articles below and match them to two of these headlines.

# FAMILY SAVED FROM
BURNING HOME

# DRIVERS INJURED IN
HIGHWAY CRASH AND FIRE

# HIT-AND-RUN DRIVER
INJURES STUDENT

Alia Nawaz, 18, was
badly injured yesterday in a
horrific accident in Harib
Street. Walking home from
school at 1.30, she was hit by
a blue Suzuki jeep which
drove straight on. Police
Officer Ali Aziz, on his way
back to 22 May Street Police

Station form highway patrol,
arrived first on the scene. He
immediately called an
ambulance for Alia, who had
a broken leg and a back
injury. Aziz says, 'This man
must be caught. If you saw
the incident, please phone
08 111111 immediately.'

Mother of two Mrs Khalifa
Al-Yamani, her son Amri, 5, and
daughter Shareefa, 2, were
rescued yesterday from a fire at
their flat in Medina Road. The
fire was seen by husband
Mustapha when he was
returning from work at 2.00.
After calling the fire service on
his mobile, he rushed to the

rescue. He was soon joined by
two fire engines from Medina
Road Fire Station. Mustapha,
helped by Fire Officer Nasser
Badawi, quickly carried his wife
and children to safety. They
were taken by ambulance to
hospital, where Mrs Yamani was
treated for burns on her arms.

Now do activities A and B in the Workbook.

41

6.2

## A lucky escape

Look at the picture. Then describe it using words that you collected in your Workbook in the last lesson and the language below. Start with the things furthest away.

In the distance, you can see ...
Nearer us, there's ...
In the foreground, there are ...

Now think about the accident. First choose and read out the correct headline from page 41. Then discuss these questions:

- What must have/may have happened?
- What is happening now?
- What is probably going to happen next?

![img-73.jpeg](img-73.jpeg)

Now do activities A and D in the Workbook.

42

## Accident at Jebel Kebir

6.3

Look at the picture. Guess what has happened and what is happening now. Then read the text to find out if you were right.

![img-74.jpeg](img-74.jpeg)

In the school holidays Anwar always helped his father Kassim with the farm. One morning, they were checking the line of beehives below the high, broken rocks of Jebel Kebir. The had nearly finished when they heard a loud crash above them. They looked up. A large rock was starting to roll. 'Look out!' shouted Kassim. Other rocks were starting to move too. 'Get back!' The heavy rocks were rolling and bouncing down from the mountain, and the ground shook. Frightened by the noise, hundreds and thousands of bees rose from the hives. 'Run, Anwar!'

But Anwar tripped and fell to the shaking ground. His hat and the thin material covering his face fell off. The noise of the rocks - and now the bees - was terrible. A large rock bounced and rolled past him, just missing his head. Kassim turned and saw what was happening. His son might be killed! He started to run back, but the angry bees were there first. In a second, hundreds of them were covering. Anwar's hands, face and neck. Kassim rushed to his son, hitting out at the bees and trying to push them away. He half pulled and half carried Anwar to safety.

***

As Kassim raced back to the village in his pick-up, he kept looking at his son beside him. Anwar groaned. The bee stings had made his face and hands look huge, and he was in a lot of pain.

Ten long minutes later, the pick-up screamed to a stop outside the clinic. District Nurse Salwa Mafouz was there. She was saying goodbye to her last patients and was getting ready to leave. Kassim jumped out, ran round to the other door and pulled his son out. Anwar's eyes were closed and he was almost unconscious. The two of them carried Anwar into the clinic, and Salwa started work immediately. 'He's been stung hundreds of times,' she said. 'I've never seen anything like it!' Then she held his wrist to check his pulse. She could only just feel it. 'Quick!' she said. 'We must get him to hospital in Hajjah.' They put Anwar on the back seat of her car, and she drove away at high speed. Kassim followed in the pick-up.

### Answer these questions.

1. What turned an ordinary job into a terrifying incident?
2. What turned the incident into a major medical emergency?

Now do activities A and B in the Workbook.

43

6.4 6.5

## Saving Anwar

Listen to the conversation. In Workbook activity A, number the pictures in the order you hear them.

![img-75.jpeg](img-75.jpeg)

Now do activities B, C and D in the Workbook.

44

# How a hospital works

6.6

You wrote about the process of saving Anwar in the Past simple. However many processes always happen in the same way. We can then write about them in the Present simple.

![img-76.jpeg](img-76.jpeg)

Read what Dr Shakir's visitor says. Do you think the process is the same in a casualty unit at a big hospital in Yemen?

Well, the process probably isn't very different from what you do here. We have a two-track system. We put people with really bad injuries in the 'fast track'. They're patients who come in by ambulance from a bad car crash, for example, or people like Anwar. They're the highest priorities, of course, and they get immediate treatment.

But most people aren't so badly injured. And we put patients like these through a longer process. In fact, if there has been a bad road accident, for example, they may just have to wait because all the doctors are busy with the high-priority patients.

So what happens is this. Receptionist register the personal details of the slow-track patients. From there, patients go and wait to see the reception nurse, who quickly examines each patient and gives them a priority - red for bad injuries and also for young children and old people, and blue for people with less serious injuries. She adds her notes to the registration form and sends it through to the team of doctors. Patients then usually have to wait again before their turn comes to see a doctor. The doctors call patients into the examination rooms and examine them carefully. The doctors may give all the treatment that is necessary. But they may send a patient for treatment by another unit - the X-ray unit for a broken bone, for example.

Read the underlined parts again. These are important steps in the process of treatment. Find and underlined three more steps Then do activity A in the Workbook.

45

SOM

6.7

## Working in public service

Read about three people who work in public service. Which one do you already know? What is her job? What words and information help you?

I grew up here when the war was terrible. I hated it. The city centre was destroyed. And that was when I decided I had to help make this place the Arab World's most beautiful city and most important business centre again. That's what I've been doing since I finished college, and we've done a lot. I really love helping to make life better for everyone here.

![img-77.jpeg](img-77.jpeg)

![img-78.jpeg](img-78.jpeg)

Even when I was young, I liked trying to help people with their problems, so my job is just right for me. I've been doing it now for three very busy years. There's a lot to do here. It's the main entry port for Hajjis from all over the Moslem World, so there are many nationalities and lots of people with cultural and social problems.

Before, there was no health care in the area. I've been working here for eight years now, and things have really improved. I visit several villages each week, and I deal with more major problems go to hospital in Hajjah. I also do a lot of health education. I feel good that we've reduced death and disease so much.

![img-79.jpeg](img-79.jpeg)

Read about the other two people. What jobs do they do? Choose from the jobs in the box. As you read, think about the words and information that help you.

customs officer district nurse English teacher, heart surgeon paramedic planning officer social worker radiographer

Discuss what all these people like about their work.

Now do activities A, B and C in the Workbook.

46

--

# Huge changes in Libyan health care

6.8 6.9

Read the title of the page, the title of the magazine article and the introduction to the article. What do you think the article will be about?

Now read the text. What important things happened in Dr Badawi's life in 1960, 1967, 1969, 1973, and 1987?

# A LONG LIFE IN MEDICINE

Dr Suleiman Badawi, Senior Surgeon at Tripoli Central Hospital since 1987, looks back on his life in the Libyan Republic.

![img-80.jpeg](img-80.jpeg)

I remember the day in 1960 when I decided to become a doctor. I was 16, and two months earlier a good friend of mine, Sadiq, had died of tuberculosis. Now it seemed my younger sister, Fareeda, was going to die too. She had measles, and her temperature was very high. We knew measles was easy to cure - with proper medical care. But the nearest doctor was 200 kilometres away. I

felt very angry as we sat with Fareeda. 'Why should good people like Sadiq and Fareeda die? I asked myself. Disease and death were common in our little country town, where there were no medical facilities at all.

Thanks be to Allah, Fareeda's temperature began to go down the next day, and she slowly got better. However, I was still angry. 'This can't go on', I thought. 'There should be medical help for everyone, not just for a few people in the cities.' That was the day my future was decided.

At that time, there were no training facilities for doctors in Libya, and I had to go to Cairo. Two years after qualifying, in 1969, when I was completing further training in a large hospital in Alexandria, news of the new Republic came.

The Republic put people at the centre of society. And for a better society, everybody needed good health care. This was exactly what I believed! The situation soon began to improve and now we have more doctors for every 1,000 patients than almost anywhere in the world.

In the old days, trachoma was a terrible disease that made many people blind. As an eye surgeon, I was extremely interested in this area of medicine. It was a great moment in my life when I was asked to run the new Trachoma Centre in Benghazi in 1973.

It is wonderful that we now have good health care, with trained medical staff in health centres and hospitals everywhere. Through hard work, we have at last stopped the terrible diseases of yesterday - malaria, tuberculosis and trachoma. I am only sorry that Sadiq cannot be here to see all these changes.

Imagine that you have been told to chose one of the jobs that you have read about in the last two lessons. Which would it be, and why? Which would you not want to do?

Now do activities A to D in the Workbook.

47

[LOGO]

6.10

## Discovering Yemen

### Talk about the picture.

Describe what you can see - first the two four-wheel-drives in the foreground and then the things further away in the distance.

Now say what you think about the picture. Where must it have been taken? Who do you think the people in the four-wheel-drives are? Where might they be going? Give reasons.

![img-81.jpeg](img-81.jpeg)

Now do activities A to B in the Workbook.

48

![A small circular logo with a stylized 'A' inside.]()

# Tourism and the future

6.11 6.12

Look at the article below. What sort of magazine do you think it is from? Look at the headline and pictures. How does it seem connected with the last lesson?

Read the article and do activity 6.11 A in the Workbook.

# DISCOVERING YEMEN

By Jim Robinson

![img-82.jpeg](img-82.jpeg)

A majestic view of the mountains as we travelled north-west from Sana'a.

# Day 3

We left Sana'a early and travelled up into the magnificent mountains to the north-west of the capital. During the long trip, I became friends with Faysal Hatem Al Qadhi, the driver of the four-wheel-drive. I found out to my surprise that he was the

owner of the little travel company that was taking us on this trip. As we talked, I started seeing him as the face of the future of Yemen. A typical Yemeni, Faysal is friendly, polite and kind, and full of energy and ambition for the future.

What Faysal told me about his business showed this clearly. Having always been interested in tourism, he started his company fifteen months ago with just one old four-wheel-drive. Now he has two new vehicles and the company is growing fast.

His ambition is to have eight or ten 4WDs two years from now and to take visitors all over Yemen. Looking a few years into the future, Faysal hopes he will have a wife and children. He doesn't want to be very rich, but he does hope to own a house and to give his family the things they need.

Does he think tourism will change Yemen? Yes, but he believes most of the changes will be good ones. For example, there will be better roads and hotels, and people will have more money. However, he doesn't feel that people will start to think about money and nothing else. He is certain that the traditional way of life is strong enough to prevent that.

Re-read the article and complete activities 6.11B, and C and D in the Workbook.

You are now going to write about yourself, what you are interested in, what you hope for and what you want to do in the future. Look at the article and find language that will help you. Underline expressions that show:

1 what Faysal is interested in
2 his ambition
3 his hopes
4 what he wants / does not want
5 what he believes

Follow the instructions in activity 6.12 A in the Workbook to complete the writing activity.

49

M

الإدارة العامة للمناهج

11

# Arts reader

---

ARTS 1

# A difficult choice?

Olivia Lee was travelling in a taxi when the taxi-driver started talking to her. He told her that he had 11-year-old twin daughters. One of them was very ill with a kidney disease.

'Why don't you give her one of your kidneys?' asked Olivia, 'or her sister could

give her one.'

'What would you know about it?' asked the taxi-driver.

Olivia told him that she was a kidney donor; she had given one of her kidneys to her brother. The taxi-driver stopped the taxi to hear her story.

Olivia had not seen her brother, Michael, for a long time. She was shocked when she saw him. He had always been athletic, lively and good fun. Now he was thin, tired and ill. He had a kidney infection that could kill him. He had two choices. He could wait for somebody with healthy kidneys to die, hope that they matched his, and have a kidney transplant. His second choice was to spend the rest of his life connected to a machine that would do the job of his kidneys for him.

Olivia immediately decided to give Michael one of her kidneys. She knew that, although people normally have two kidneys, some people are born with only one and live normal lives.

Olivia told the taxi-driver that when she arrived at the hospital, the doctor had explained that there is always some risk in an operation, but the risk is small for a healthy person. However, the operation would be more serious for Olivia than for her brother. He would have to cut deeply into Olivia's body to remove her kidney without damaging it. The scar from the cut would be 30 centimetres long. She also learned that she would be in hospital for a week to ten days and then have to rest for three to four weeks.

Nevertheless, the operation was successful. Michael is now leading a normal, healthy life. Olivia has a scar to

remind her of the operation, but she does not feel any different. Her advice to the taxi-driver was this: 'If you are close to somebody, don't hold back. It's worth the pain and the small risk.'

That may be so, but it is also true that Olivia gave her brother the greatest gift she could have given him – life.

(This story is true, but the names have been changed.)

![img-83.jpeg](img-83.jpeg)

# Discussion

* From what you now know, would you donate one of your kidneys to a brother or sister?

51

ARTS 2

# Proverbs and idioms

'Half a loaf is better than no bread at all' and 'look down your nose at something.' Which is a proverb and which is an idiom? Being able to answer this is a sign that you know - or are on

the way to knowing - how English works. Of the two, idioms are the most widely used. Choosing the right idiom and using it at the right time is a sign of real progress in English.

# Proverbs

A proverb is a sentence that expresses a truth or moral lesson. There are proverbs in most languages and some are very old.

Match these English proverbs with the explanations.

Proverbs

1 Half a loaf is better than no bread at all.
2 One man's meat is another man's poison.
3 Actions speak louder than words.
4 No man can serve two masters.
5 One good turn deserves another.

Explanations

a A person cannot serve two opposing groups or ideas.
b Having something is better than having nothing.
c A person's actions are more important than what he or she says.
d If someone does something kind for you, you should return this by doing something just as kind.
e What is good for one person may not be good for anyone else.

What about these proverbs?

Many hands make light work. Too many cooks spoil the broth.

They have the opposite meaning. Broth, by the way, is a kind of soup.

Do you have any pairs of proverbs in Arabic that have opposite meanings?

# Idioms

Idioms are very common in English and they can be very difficult for learners to understand because the general meaning is different from the meanings of the words used. Like language, idioms change with time, and some idioms that were widely used ten years ago, can sound old-fashioned today.

Sometimes the same word is used in different idioms. Read these idioms and match them to the pictures.

lead someone by the nose

pay through the nose

poke your nose into something

look down your nose at something

can't see beyond the end of your nose

Ahmed should be thinking about getting a job, but he can't see beyond the end of his nose.

Be careful of those chairs! I paid through the nose for them.

![img-84.jpeg](img-84.jpeg)

Can you think of any Arabic idioms that use the same words?

52

ARTS 3

# Telford Hall Episode 1

Ahmed Hassan Al-Hadrami glanced at his new watch, a present from his parents. 'Only a quarter of an hour to go,' he thought. He was on a train to Norton College in the North of England to do a three-year course in town planning.

The train started to slow down. Through the window, he could see the first buildings of the town. The sky was grey and streams of rain were running down the glass. 'I hope the weather isn't always like this,' he thought.

Ahmed dragged his two large suitcase through the door of Telford Hall. A woman with silver hair was sitting at the reception desk.

'Good evening. My name's Ahmed Al-Hadrami.'

'I'm Mrs Dale,' said the woman. 'welcome to Telford Hall. You're in room 123 on the first floor. Derek!' A tall young man with curly fair hair appeared.

'Hi,' said Derek. 'Derek Barker. Second-year engineering. Let me help you with your cases.'

'Thank you very much,' said Ahmed.

'Don't mention it,' replied Derek. 'See you at dinner in five minutes.'

In the dining room, Ahmed was looking at a dish in the middle of the table. He turned to Derek.

'What's that?' he asked.

'Shepherd's pie,' replied Derek. 'Meat and onions covered with mashed potatoes.'

Ahmed frowned. 'What kind of meat?' he asked.

'Beef, sometimes lamb,' said the student on his left. 'My name's Bob Wilson.'

'Ahmed Al-Hadrami,' said Ahmed. They shook hands.

'Look,' said Derek, 'you're both new. Why don't I show you around the town tomorrow? It's quite interesting.'

'Thank you,' said Ahmed.

'Yes, thank you,' said Bob. Oh, by the way, Ahmed, I'm doing town planning. What about you?

After dinner, Ahmed went up to his room. He was tired. He unpacked, then lay on his bed and looked around. It had been a long day. He

had flown all the away to England and found Telford Hall. He had met Bob, Derek and Mrs Dale. And he had found out what shepherd's pie was. 'So far, so good,' he thought.

After one week at Norton, Ahmed was starting to feel at home. Derek had shown him and Bob Wilson around the town and he had found out a lot himself. He had strolled down narrow streets on old stone pavements. Their names told the history of the town: Mill Street, Silk Street, Canal Street, weaver's Square, Loom Hill ...

As part of their town planning curse, Bob and Ahmed had a lecture every Wednesday on the development of Norton.

'Towards the end of the 18th century,' the lecturer said. 'coal was discovered nearby and very quickly Norton changed from an agricultural market town to an industrial centre. The small water-powered factories in the hills closed one by one and new factories opened in the town. And for your assignment, I want you to fill in these questionnaires. You need to go out into the country and find out about those old factories, such as when they closed and how many people worked in them.' The lecture ended.

'Now I have to buy a car,' Ahmed said to Bob.

'What!' exclaimed Bob. 'Why?'

'How else can we get out into the country?' asked Ahmed.

'And that's my final offer,' said the car salesman.

Ahmed and Bob walked around the car again. It was a black London taxi, about ten years old, but in good condition. Ahmed had wanted one ever since he had seen a programme about London on television.

'Done,' said Ahmed. The next day, he and Bob drove into the country.

# Discussion

- What have you learned from the story about England and English student life?
- How is life in England different from life in your own country?

53

ARTS 4

## A famous play by Shakespeare

The story of a play is called the plot. The people in the play are called the characters. William Shakespeare wrote 37 plays - tragedies, comedies and histories. Which kind is this play?

### *Hamlet*

This play is about murder and revenge. Hamlet is Prince of Denmark. His father, the king, dies. A short time later, Gertrude, Hamlet's mother, marries again. She marries Claudius, Hamlet's uncle, who becomes the new king. Hamlet is angry at his quick marriage. Then the ghost of the old king appears to Hamlet and tells him that Claudius killed him by poison. He asks his son to revenge his murder. Form that time on, Hamlet can think of only one thing - killing Claudius.

Polonius is an adviser to the king. He has a daughter, Ophelia. She loves Hamlet, but she finds that he has changed. She does not know why this has happened, but she believes that she has lost his love. Then, by accident, Hamlet kills Polonius. This is too much for Ophelia. She goes mad, falls into a river and drowns.

Laertes, Ophelia's brother, blames Hamlet for the deaths of his father and his sister. He decides to kill Hamlet. He gets help from Claudius, who also wants Hamlet dead. A sword fight is arranged between Hamlet and Laertes. It is to be an exhibition only, with the points of the swords covered so that nobody can get hurt. However, Laertes leaves his sword uncovered and puts poison on the point. The fight begins, with Gertrude and

![img-85.jpeg](img-85.jpeg)

Claudius watching. Claudius has prepared a drink for Hamlet with poison in it in case Laertes fails. When Laertes cuts Hamlet with his sword, Hamlet is surprised. He manages to knock Laertes' sword from his hand and exchange swords. Then he stabs Laertes, who falls dying. In the meantime, before Claudius can stop her, Gertrude takes some of Hamlet's drink and dies. The dying Laertes tells Hamlet everything. Then Hamlet turns and kills Claudius. Soon after, Hamlet dies from the poisoned sword.

#### Discussion

- Was Hamlet good or bad?

54

ARTS 5

## Telford Hall Episode 2

The weeks passed. Winter was approaching and the days were getting shorter. One day, Ahmed heard the other students talking about going home for Christmas. He realized that he would soon be by himself for three weeks. Suddenly he missed home: the warm evenings walking on the beach, camping in the desert, his friends ... He wondered what his mother was cooking for the evening meal that night. He was lying on his bed looking at the ceiling when there was a knock on the door. It was Bob.

'Hi, Ahmed. Listen,' he began. 'I've just been on the phone to my parents and they asked me to invite you to spend Christmas with us. Would you like to come?'

'Dear Khaled,' Ahmed began. He was sitting in the lounge at Telford Hall, writing a letter to his brother, Khaled. Ahmed wanted to tell Khaled all about Christmas, Bob's parents lived near Liverpool and had taken him to lots of places in the city and the surrounding countryside. On Christmas Day, Bob's older sister, Jenny, had come with her husband, Graham, and their two children. It had been strange to hear the children call Bob 'Uncle.'

One morning, Ahmed said to Bob, 'You're eating in my room this evening.'

'Why?' asked Bob.

Ahmed explained about *Ramadan*. He explained that every Moslem fasted dawn to dusk during that month.

'It must be difficult,' said Bob.

'It sometimes is,' answered Ahmed, 'but it's our duty. And we look forward to *Eid al-Fitr*.' 'What's that?' asked Bob. Another explanation followed.

'Well, it's tonight. I've invited Mick, Jerry and Derek and a couple of others. You can come, can't you?'

'Try to keep me away!' Bob exclaimed.

'Where do I sit?' asked Derek as he came into Ahmed's room.

'Anywhere,' said Ahmed.

He had pushed all the furniture to one end

![img-86.jpeg](img-86.jpeg)

*Christmas lights in Norton*

of his room and everybody was sitting on the floor around a brass tray his parents had sent him. It was now piled high with meat and rice. On Ahmed's desk there were two dishes of sweet pastry made with honey and nuts.

'Who made all this?' asked Bob.

Ahmed explained that he had given the recipes and spices to the cooks in the kitchen of Telford Hall and spent the afternoon helping them. He played some cassettes from home and later passed around the dishes of sweet pastry. Earlier in the day, he had phoned his family to wish them a good *Eid* and he was a little sad that he was not at home. But Ahmed felt good celebrating *Eid al-Fitr* with his new friends.

At the end of the first year, town planning students had to do six three-hour exam papers, one every morning and afternoon for three days. Ahmed had been studying hard and he decided to relax before the exams and take the weekend off. He wanted to visit Stratford-upon-Avon. Bob had agreed to go with him.

55

--

ARTS 5

![img-87.jpeg](img-87.jpeg)

Shakespeare's birthplace!

The next Saturday morning, they were walking around this famous town, which is about three hours' drive from Norton. They stopped in front of one of the many old houses still standing in Stratford.

'Here we are,' said Bob.

'You mean this is the actual house?' asked Ahmed, surprised.

'Yes,' answered Bob. 'This is the actual house where Shakespeare was born on April 23rd, 1564.'

Ahmed could not believe it. He knew that Shakespeare was born in Stratford, but he had never imagined that the actual house would still be there.

'Let's go in,' suggested Bob.

All the furniture in the house was from the 16th century. In the living room there were heavy wooden chairs and cupboards. Even the cooking equipment in the kitchen was from that period. Upstairs they walked through the room where Shakespeare was born and saw the desk where he studied as a schoolboy. Ahmed was fascinated.

They stayed the night at the local Youth Hostel and spent the next morning rowing on the River Avon, which gives the town part of its name.

'What's that?' asked Ahmed, pointing to a huge brick building by the side of the river.

![img-88.jpeg](img-88.jpeg)

The Royal Shakespeare Theatre on the River Avon

'The Royal Shakespeare Theatre,' answered Bob. 'They perform Shakespeare's plays there. They do three of four different ones every year.'

'How many plays did he write?' asked Ahmed.

'Thirty-seven,' said Bob.

Before they left Stratford, Ahmed wanted to buy some souvenirs. In the tourist shops, you could buy Shakespeare teapots, Shakespeare dolls, and even Shakespeare toothbrushes. Everything had 'Shakespeare' on it. Ahmed bought a book of photographs of the town. He also bought some copies of Shakespeare's plays and a special mirror. Shakespeare's beard, eyebrows and hair were painted on the mirror so that when you looked at yourself, you looked like Shakespeare.

'I'll give it Khaled,' said Ahmed. 'I think he will like it.'

# Discussion

- Explain Eid Al-Fitr in English.

56

ARTS 6

# Critics and criticism

### Professional critics of the arts

Why do you watch one film and not another? Why do you buy one compact disc and not another? Perhaps a friend recommended them, and, of course, you have your own personal taste. However, your opinions and tastes as well as your friend's may have been influenced by critics.

The verb 'to criticize' means to make a judgement about something or somebody. A critic is a person who makes judgements about the arts, that is literature, sculpture, films, music, television programmes and so on. The critic helps the public to decide whether a new book or film, for example, is good.

The reports that critics write are called 'reviews'. After people read reviews they decide whether they want to buy a particular compact disc or watch a particular video.

### Making judgements

Critics comment on works of art in many ways. In poetry, the critic looks at the language the poet uses and how well this expresses what he or she wants to say. When discussing a painting, one critic may describe only the technique - how the artist painted the picture. Some critics think that the artist's life is important. One film critic will talk about how interesting the story of the film is; another will concentrate on how it was filmed; another may comment only on the acting.

### The importance of critics

Critics are important in two ways. First, they can have an immediate effect on the success of a work of art. If a film gets bad reviews, people might not want to see it. Secondly, critics draw the attention of the public to new works.

Critics help us have a better understanding of the arts. However, they cannot tell us what to think. In the end, we have to make up our own minds.

#### Other uses of *critic*, *criticism*, *criticize* and *critical*

1. Ahmed has his **critics**. = There are some people who say that Ahmed does everything wrong.
2. The new building got a lot of **criticism**. = A lot of people didn't like the new building.
3. Stop **criticizing** me. = Stop saying I do everything wrong.
4. Ahmed is a very **critical** person. = Ahmed criticizes things or other people a lot.
**or**
The game has reached a **critical** stage. = The game has reached a very important stage.

#### Discussion

- Do you use your own judgement to choose books and videos, or do you wait to hear what other people or critics say?
- Do you agree that critics do a useful job?

57

ARTS 7

# Telford Hall Episode 3

On the morning of the final examinations, the sun was shining brightly.

'Lovely day,' said Ahmed.

'It always is when there's an examination,' said Bob.

He and Ahmed were walking through the college gardens on their way to the main hall, where the examinations were held. There was a crowd of students waiting outside. At 9.45 exactly, the doors opened and the students poured into the hall, where rows of desks stood waiting. On each desk, there was a name card and a piece of paper, face down: the examination paper! Ahmed found his place.

![img-89.jpeg](img-89.jpeg)

A large exam hall

A lecturer Ahmed had never seen was supervising the examination.

'Attention everyone,' he said slowly and loudly. 'As you know, the examination lasts for three hours. When I say "begin" turn over your papers and start. Good luck. Begin!'

By the time he finished the last paper on Friday afternoon, Ahmed's arm ached from writing so much, but he did not mind. He was just happy that the exams were over. The examination results would come out the following week and Ahmed had decided to stay

in Norton until then.

'Are you staying in Norton or going home?' he asked Bob.

'Oh, I almost forgot,' said Bob. 'My parents phoned last night. They would like you to come home with me and stay with the family for a few days.'

'I'd love to,' said Ahmed. 'We'll take the taxi.'

On the following Sunday morning, Ahmed, Bob and his mother went for a walk along the beach. Bob's father stayed at home to cook lunch.

'He always cooks Sunday lunch,' she explained, 'roast meat and vegetables - and he doesn't like being disturbed.'

Next to the beach there were high sand dunes.

'They remind me of home,' said Ahmed.

When they got back to the house, they were met by a wonderful smell coming from the kitchen.

'Smells delicious,' said Ahmed.

It tasted delicious as well: perfectly cooked roast beef with four different vegetables and a special sauce.

After lunch, everybody helped with the washing up and it was soon finished.

'Many hands make light work,' said Bob's mother.

For the rest of the afternoon, they sat and talked or read the thick Sunday newspaper. Bob's sister and her family called in to say 'hello'. When they had gone, Ahmed, Bob and his father played a word game, like a crossword puzzle. In the evening, they all watched an old film on television. Later, just before he fell asleep, Ahmed thought about how much he had enjoyed spending a quite Sunday in Bob's home. It made him miss his own family.

Bob and Ahmed arrived back in Norton on the day the examination results came out. The list of results was on a notice board in the main college building.

58

Teflon

ARTS 7

'Our names, Ahmed: they're not on the list!' said Bob, worried.

'You're looking in the wrong place,' said another student. 'Look at the top of the list.'

Bob had been looking for the two names among the B and C grades, but under grade A were the names Robert Wilson and Ahmed Hassan Al-Hadrami.

'That will make your father happy,' said Bob. 'When are you going home, by the way?'

'The day after tomorrow,' replied Ahmed.

'Now, Bob, you will take care of the taxi while I'm away, won't you?' said Ahmed.

'Of course,' said Bob. 'Don't worry about a thing.'

They were standing on the platform of Norton Central station, waiting for the London train. It was raining.

'It was raining when I arrived,' said Ahmed.

'At least the rain is warmer now,' said Bob.

The train arrived. Ahmed got in, stood by the door and opened the window.

Telford Hall,
Norton,
Friday.

Dear Mr and Mrs Wilson,

Thank you very much for having me to stay for the past few days. I had a wonderful time and you really made me feel like one of the family.

I hope one day that I will be able to repay your kindness and hospitality.

Thank you again.

Best wishes,

Ahmed

![img-90.jpeg](img-90.jpeg)

Looking down on London from the plane

'See you in October ...' he shouted through the window as the train moved out of the station.

'Have a good journey ...' shouted Bob, waving at his disappearing friend.

Ahmed sat down and looked out at the countryside moving past. Nine months ago, it had seemed strange to him, but now he knew it so well. He started thinking about the places he had been and the friends he had made. There were so many. The train stopped. He was in Euston station. Four hours later, he was sitting in the plane looking out over London. He could see the city clearly. Then the plane went up through the clouds Ten hours later, he would be home.

# Discussion

- Does your family spend Fridays in a traditional way?
- Compare your Fridays with English Saturdays.

59

ARTS 8

# Calligraphy

The word 'calligraphy' comes from Greek. It means 'beautiful writing'. It is the art of fine handwriting and has been practised in many countries for centuries. In the Far East, a pointed brush is used. In Western and Islamic cultures, a pen is the calligrapher's tool.

![img-91.jpeg](img-91.jpeg)

Calligraphy in China has a history going back thousands of years. There was a strong connection between painting and calligraphy because they used similar methods and materials. However, calligraphers were seen as scholars, while painters were seen as ordinary workers. It was not until the 5th century that they were treated as equals.

In Western cultures, calligraphy was based on the Roman letters. Different styles were developed from these basic shapes. Calligraphers were often religious men and the most beautiful examples of Western calligraphy are usually found in religious books. The pages are made beautiful by the shapes of the letters, the pictures added as decorations, and by the right colours used.

![img-92.jpeg](img-92.jpeg)

Calligraphy among the followers of Islam was seen as the greatest of the arts, because of the importance of the writing of the Holy Koran. Therefore, many calligraphers concentrated the name of God.

![img-93.jpeg](img-93.jpeg)

As Islam spread, so did calligraphy. The art grew and developed and two main styles appeared. *Kufic*, an angular style for carving in stone, appeared in the 7th century. By the 10th century, *Nashki*, a more flowing style with rounded letters, appeared and *Kufic* had almost disappeared. New forms of calligraphy also appeared in art and architecture. Artists twisted words into circles, squares and other shapes, small enough to fit on a plane or large enough to decorate the wall of a mosque. Birds, fruit, animals and even the shapes of mosques, ships and the Islamic Star and Crescent became part of the calligrapher's art.

A number of young artists today are interested in traditional calligraphy. A good example is a piece of modern calligraphy in the shape of the Hand of Fatimah. It was designed as a greeting card by the Lebanese artist Mouna Bassili Sehnaouri some years ago. It reads *Ma sha 'Allah* - 'As God wills'.

# Discussion

- • Is calligraphy important today?
- • Should writing be easy to read or beautiful?

60

ARTS 9

# A poem

# LEISURE

by William Henry Davies 1871-1940

What is this life if, full of care,
We have no time to stand and stare.

No time to stand beneath the boughs
And stare as long as sheep or cows.

No time to see, when woods we pass,
Where squirrels hide their nuts in grass.

No time to see, in broad daylight,
Streams full of stars like skies at night.

No time to turn at Beauty's glance,
And watch her feet, how they can dance.

No time to wait till her mouth can
Enrich that smile her eyes began.

A poor life this if, full of care,
We have no time to stand and stare.

|  care | worry  |
| --- | --- |
|  stare | look closely  |
|  boughs | branches  |
|  squirrels | small animals  |
|  broad daylight | full light of day  |
|  streams | small rivers  |

![img-94.jpeg](img-94.jpeg)

Listen to the poem. Does listening help you to understand it?

# Discussion

- Do you agree with the poet's view?
- Add ones stanza (two lines) to this poem.

61

ARTS 10

# Strange happenings

# The Bermuda Triangle

The Bermuda Triangle is a name given to an area of the Atlantic Ocean between the islands of Bermuda and Puerto Rico and the coast of the State of Florida in the USA. It is famous because many ships and planes have disappeared there.

![img-95.jpeg](img-95.jpeg)

Perhaps the biggest mystery is the loss of five US Navy planes in 1945. At 2pm on December 5th they took off from Fort Lauderdale to fly over the Bermuda

Triangle. The weather was perfect. Soon afterwards the leader of the flight sent this message on the radio: 'We are off course ... we cannot see land ... everything is wrong and strange ... the ocean doesn't look the way it should ...' And then silence. Another aircraft was sent to look for the missing planes, but it too was never seen again. In total, six planes and 27 men had disappeared.

Nobody has ever been able to explain this or any of the other disappearances. Over 150 ships and planes and more than 1,000 people have been lost in this part of the ocean.

# The curse of Tutankhamun

Tutankhamun was the king, or Pharaoh, of Egypt over 3,500 years ago. He died when he was only 10 years old and was buried in Luxor in southern Egypt. As was the custom in those days, his tomb, the room where his body lay, was filled with treasure and then closed in. In later years, robbers used to break into the Pharaoh's tombs to steal the treasure, but the tomb of Tutankhamun stayed hidden for centuries. Then in 1923 the British archaeologist, Carnarvon, found and broke into the tomb. Above the gold coffin of the boy king was a piece of writing, which Carnarvon translated. It read: 'Death will come to those

who disturb the sleep of the 'Pharaohs.'

Two months later, Carnarvon was dead. Doctors said that he had been bitten by a mosquito. Other members of his team died of mysterious illness soon afterwards : after six years, 12 of the people who had broken into the tomb were dead. Other deaths followed. In

1972, the treasure of Tutankhamun was flown to London by plane for an exhibition. For years later, the pilot of the plane died suddenly at the age of 40. At the time his wife said: 'It's the curse of Tutankhamun - the curse that killed him.

![img-96.jpeg](img-96.jpeg)

Tutankhamun

# Eryl's dream

The main industry of Aberfan, a small town in South Wales, used to be digging for coal. Coal dust and small pieces of coal could not be sold, so they were piled up in heaps, called slag heaps. They were like small, black mountains. There was a primary school in the town and, on the hill above the school, was a slag heap. Eryl Jones went to the primary school in Aberfan. One day she told her mother about a dream. She dreamed that she had gone to school, but the school was no longer there. 'Something black had come over it,' she said. Two days later the slag heap slid down the hill and covered the school. 144 schoolchildren and teachers died.

# Discussion

- Try to explain these three things.
- Can you think of any happenings like these?

62

الإدارة العامة للمناهج

11

# Science reader

---

# SCIENCE 1

# Acids and alkalis

# Definitions

An acid has a sharp or sour taste. In fact the word acid comes from a Latin word that means sour. Acids corrode, or eat away at, metals and rocks. In chemistry a base is a substance that reacts with acids to produce salts. Bases that dissolve in water are called alkalis. The word alkali is from Arabic and means 'the ashes of a plant'. Acids and alkalis neutralize each other.

# Detecting and measuring acidity and alkalinity

# The litmus test

Litmus is a vegetable dye that is used to test the acidity of solutions. Litmus paper is soaked in this dye. It is green, but when put in an acid solution, it turns red. If the solution is alkaline, it turns blue.

# The pH scale

The strength of an acid or alkali is measured on the pH scale. This measures the concentration of hydrogen ions on a scale of 0 to 14. Low numbers show high acidity. On this scale,

![img-97.jpeg](img-97.jpeg)

soap has a pH value of 9.5 and distilled water a value of 7, which is called a neutral pH value. A pH meter, or an indicator such as litmus paper, is used to measure pH values.

# Acids and alkalis in everyday life

# Acid rain

The gases released by burning oil and coal and from car engines react with water in the atmosphere to produce rain that contains acid. This acid rain, with a pH value between 2.2 and 5, corrodes building materials, damages plants and pollutes lakes so that fish die.

# Soil

Plants will not grow in soil that is very acidic or very alkaline. Most plants prefer soil with an almost neutral pH value.

# Wasp and bee stings

![img-98.jpeg](img-98.jpeg)

![img-99.jpeg](img-99.jpeg)

# Common alkalis

Baking powder is bicarbonate of soda.
Its chemical formula is NaHCO3.
Lime is calcium hydroxide.
Its chemical formula is Ca(OH)2.

# Common acids

![img-100.jpeg](img-100.jpeg)

![img-101.jpeg](img-101.jpeg)

![img-102.jpeg](img-102.jpeg)

# Discussion

- What other common acids and alkalis do you know?

65

SCIENCE 2

## States of matter

In science, the word 'matter' is used to describe what things are made of. Matter comes in three different forms, called states: solid, liquid and gas.

Solids have a fixed shape that cannot easily be changed. Liquids have no fixed shape and can only be picked up in a container. Gases are even less easy to hold. They have to be kept in closed containers or they will escape into the air and spread very quickly. For example, you will soon be able to smell gas all over your house even if there is just a small leak in the gas container in your kitchen.

The kinetic theory states that matter is made up of particles that are always in motion – always moving. This theory helps us understand the different properties that matter has in its three states. In a solid, particles are packed together like balls in a box and can hardly move. Heating the solid gives the particles more energy. They move

more quickly, and are pushed apart. If there is enough heat, the particles have enough room to change places. This is when the solid becomes a liquid.

More heat makes the particles move even faster and travel further apart. They can then move freely to fill any space they are in. This third state of matter is called gas.

![img-103.jpeg](img-103.jpeg)

![img-104.jpeg](img-104.jpeg)

![img-105.jpeg](img-105.jpeg)

### The three states of water

Water is the only substance that is easy to find in the three states of solid, liquid and gas – as ice, water and water vapour or steam. The properties of water are very important for life on Earth.

![img-106.jpeg](img-106.jpeg)

66

S

SCIENCE 3

# Light

# Definition

Light is a form of energy. Over the years, physicists have had different ideas about how light behaves. First some said it acts like a stream of particles. Later others observed that light acts like a wave that can travel through a vacuum, such as outer space. Most recently, the quantum theory has stated that it is a combination of both.

# Reflection

We see something when an object emits light, reflects light like a mirror, or changes light passing through it. We see most things by reflection. When you look at your desk, what you really see is light reflected from the desk. How much light is reflected depends on the surface that the light hits. A smooth white surface reflects more light than a rough black one. On a smooth surface, the angle at which light hits it is the same as the angle at which it is reflected. On a rough surface, these angles are different because the surface scatters the light.

![img-107.jpeg](img-107.jpeg)

# Refraction

Put a spoon at an angle in a glass of water. Stand back and look at it. The spoon appears to bend or split into two parts. This happens because light waves bend when they pass from one transparent medium to another. This effect is called refraction.

Refraction is made use of most commonly in *lenses*. Lenses are specially-shaped pieces of glass that refract light exactly. There two types of lenses.

A convex lens is thicker in the middle than at the edges and can make objects look larger. A concave lens is thinner in the middle than at the edges and makes objects look smaller.

![img-108.jpeg](img-108.jpeg)

![img-109.jpeg](img-109.jpeg)

# Discussion

- What is our main source of natural light?
- When does a raindrop act like a prism?
- When do we use lenses?

67

SCIENCE 4

# Sound

# SOUND WAVES

Sound travels as waves. Unlike light waves, sound waves need a substance, such as air, to travel through. Because sound waves cannot travel through a vacuum, there is no sound in outer space.

Sound is created by something vibrating. As the source of the sound vibrates - an *oud*

string, for example - the molecules in the air near the source are squeezed together. They, in turn, hit against the molecules next to them and are pulled back into place by the molecules behind them. In this way, sound waves move through the air.

# FREQUENCY

Sound range from very low to very high. What makes the pitch different is the frequency of the sound waves. Frequency is measured in hertz (Hz) - the number of waves per second. One hertz is equal to one wave per second. A person with very good hearing can hear sounds down to about 20 Hz and up to about 20 kilohertz (kHz), or 20,000 Hz.

Sound waves can be represented by graphs showing how the intensity, or strength, varies with time. These graphs represent sound of three frequencies. At a frequency of 20 Hz, 1 complete wave occurs in ½ second. At a frequency of 50 Hz, there are 2½ waves during the same time, and at 100 Hz there are 5.

![img-110.jpeg](img-110.jpeg)

# ULTRASONIC SOUND

Frequencies higher than those that can be heard by people are called ultrasonic, meaning 'beyond sound'. One of the special qualities of ultrasound is that it does not spread out nearly as much as ordinary sound, so it can be directed almost like a beam of light. In industry, it can be used to find invisible flaws in solid metals.

![img-111.jpeg](img-111.jpeg)

Ultrasonic sound can be heard by many animals. Bats and dolphins can produce and hear sounds of 120 kHz or more. Ultrasonic sound allows bats to 'see' in the dark and dolphins to find their way underwater.

# VOLUME

Volume, or loudness is measured in decibels (dB). The sound of people talking measures between 50 and 70 dB; the sound of a jet

plane taking off measures between 110 and 140 dB. Sounds of more than 120 dB cause pain and can lead to deafness.

# Discussion

How is ultrasound used in medicine?
What is the loudness sound you have heard?

68

SCIENCE 5

# Arab scientists

Most people have heard of such scientists as Newton, Jenner, Einstein and Fleming. What people in the west often forget is their debt to their equally important predecessors: the Arab scientists. Isaac

Newton said, 'If I have seen further, it is by standing on the shoulders of giants.' He could have been talking about Ibn Sinna, Al-Khawarizmi, Ibn Al-Naifs, Ibn Al-Haytham or Jabir Ibn Hayyan.

![img-112.jpeg](img-112.jpeg)

Ibn Al-Naif's was a physician famous for discovering the blood's circulation system. He was born in Damascus in 607 and educated at the Medical College, Damascus. He made many important contributions to medical knowledge at that time. For example, he was the first person to explain how the lungs worked.

Al-Khawarizmi was a great mathematician, geographer and astronomer who died in 850. He invented the zero,

negative numbers, the decimal system and algebra. The term algorithm (used in computer programs and software) is named after a variation of his name, Al-Gorithmi.

Jabir Ibn Hayyan (721-776) was a pharmacist and a chemist who spent most of his life in Damascus. He is known as the father of molecular chemistry. Among his many inventions was a scale capable of weighing objects as light as 0.1587 of a gram. He also developed anti-rust coatings and fluorescent ink.

Ibn Sinna was born in 980 near Bukhara in what today is Iran. After finishing school, he taught himself logic, mathematics, science,

philosophy and medicine. He moved to Isfahan in 1022 and wrote his two most important books, the Book of Healing and the Canon of Medicine. These books were standard sources of medical knowledge for many centuries.

![img-113.jpeg](img-113.jpeg)

Perhaps the most famous of all the Arab scientists was Ibn Al-Haytham (died 1039). He greatly influenced later scientists like Sir Isaac Newton. Before Al-Haytham, people believed that vision was the result of a beam of light being emitted from the eyes. This did not explain why the size of an object depends upon its distance from the person looking at it. Ibn Al-Haytham proved that when we look at an object, the image occurs in the brain, not in the eyes. His research led him to think about how we recognize things. Al-Haytham showed that the brain is able to compare the new image with those stored in its memory. He realized this was the key to understanding vision.

![img-114.jpeg](img-114.jpeg)

# Discussion

- What other Arab scientists do you know?
- In what ways are they important?

69

SCIENCE 6

![img-115.jpeg](img-115.jpeg)

![img-116.jpeg](img-116.jpeg)

# Vaccinations

Before the late 18th century, thousands of people died every year from such diseases as smallpox, typhoid and cholera. Doctors tried unsuccessfully to treat patients with these diseases while scientists struggled to find suitable cures. The big breakthrough came from an unexpected source: an unknown country doctor in England.

Dr Edward Jenner was

![img-117.jpeg](img-117.jpeg)

![img-118.jpeg](img-118.jpeg)

experimenting with ways of vaccinating against smallpox when he noticed that people working with cows did not suffer the disease. On May 14th, 1796, Jenner

successfully used the first vaccine against smallpox to immunize a patient. The word vaccine comes from the Latin cow, because Jenner's vaccine was developed from cowpox, a disease similar to smallpox but only found in cattle. Jenner's work with a cowpox vaccine was the first scientific attempt to control a disease by immunization.

A century later, the next significant

development was made by a French chemist, Dr Louis Pasteur. He developed Jenner's work and showed that diseases are spread by germs.

He also proved that vaccination using a very weak form of the disease could lead to immunity. Pasteur's breakthrough came in 1885 when he treated a boy who had been bitten by a rabid dog. Although Pasteur was successful, many other doctors were against the idea of vaccination. They felt that it was dangerous. They were soon proved wrong, and by the 20th century vaccines were commonplace.

AIDS is one of the most feared diseases in history. Millions of dollars are being spent on research into developing a vaccine against AIDS. Scientists think that AIDS developed from the blood of monkeys in Central Africa. The first cases of AIDS in humans were diagnosed in the early 1970s. Once AIDS had infected people, transmission around the world was rapid. Modern drugs have helped with some aspects of the illness, but they do not provide a cure. The only long-term hope is in the development of a vaccine. We need the modern-day equivalents of scientists like Jenner and Pasteur.

![img-119.jpeg](img-119.jpeg)

# Discussion

- Is it right to introduce a disease - even a weak form - into a person's body?

70

SCIENCE 7

# Experimental procedures

![img-120.jpeg](img-120.jpeg)

When you carry out a scientific experiment, every stage of the process should be recorded and written up as a full report to show your results and conclusions. Such reports help you think about what you did and point you towards possible solutions to problems.

Without a correctly written-up procedure, it is impossible to monitor scientific progress or exchange scientific information.

The starting point for scientific experiments is to answer a question, for example: *What happens when you heat wood/metal/plastic?* Experiments should always be measurable and show cause and effect.

![img-121.jpeg](img-121.jpeg)

![img-122.jpeg](img-122.jpeg)

Reports on experimental procedures should follow these (or similar) guidelines:

# Writing experiments

Your name: ...

Date: ...

TITLE: ...

QUESTION: The question should be detailed.

RESEARCH: This should be one or two sentences describing the information you know about the question. It should be the information on which you base your hypothesis.

HYPOTHESIS: This is an educated guess – a statement based on your previous research and experience that should answer the question.

MATERIALS: A list of **everything** needed for the experiment.

PROCEDURE: A step-by-step list of **numbered** instructions showing how to do the experiment. Each step should start on a new line and usually begin with a verb.

DATA: This is information collected during the experiment. It should include:

- all measurements and observations
- tables showing the data
- numerical data shown as graphs

SUMMARY: The summary is one or two sentences that explain the data.

CONCLUSION: This can have four parts :

- analyse the data
- see if your hypothesis was correct
- describe or explain your evidence
- identify experimental errors

# Discussion

- What experiments would you like to carry out?
- Why are experiments important for progress?

71

SCIENCE 8

# Internal combustion engine

When you turn the key in the ignition of a car, a lorry, a motor cycle or any other petrol-powered vehicle, you switch on the electrical circuit. Turn it again and you can start the engine. But what happens inside the engine? What is the sequence of events? These and other questions can be answered by explaining the sequence in one cylinder in step-by-step detail:

# Action

![img-123.jpeg](img-123.jpeg)

Turning the ignition key

Piston moves down A

![img-124.jpeg](img-124.jpeg)

Piston at bottom of stroke

Piston rises B

![img-125.jpeg](img-125.jpeg)

Spark plug provides ignition C

Mixture explodes

Piston rises again D

![img-126.jpeg](img-126.jpeg)

Piston at top of cylinder

This cycle is known as:

INDUCTION - COMPRESSION - IGNITION - EXHAUST

# Result

The starter motor turns the engine. The piston moves up and down.

Petrol and air are sucked in through the open inlet valve at the top of the cylinder. The air and petrol mixture is controlled by the carburettor.

The cylinder is full of air and petrol.

Air and petrol mixture is compressed.

At the top of the cylinder is the spark plug. This provides the electric spark that ignites the mixture.

The piston is forced down.

The burnt mixture is pushed out of the exhaust valve.

The inlet valve opens again and the cycle is repeated ...

# Discussion

- The internal combustion engine was invented at the end of the last century. We are now at the end of the 20th century. Is it time for a new source of power?

72

SCIENCE 9

# The Moon

The Moon is the only natural satellite of the Earth. It has a radius of 1,738 km. The Moon orbits the Earth. At the same time, the Earth moves around the Sun. Because of both movements, it takes the Moon just over 29 days to return to its original position. We can see the Moon because of light from the Sun, which always comes from the same direction. Because the position of the Moon changes in relation to the Earth, we see greater or lesser parts of the Moon as it travels around the Earth. What we see is known as the phases of the Moon. The most we ever see is one half of the Moon (Full Moon) and it is always the same half. This is because the Moon rotates, or prints, around its own axis as it moves through space.

![img-127.jpeg](img-127.jpeg)

The Moon's phases depend on what fraction of its sunlit hemisphere can be seen from Earth. As the Moon orbits Earth, it grows in size from New Moon (1) to Crescent (2), First quarter (3), Gibbons (4) and Full Moon (5). It then decreases in reverse order to Gibbons (6), Third quarter (7), Crescent (8), and back to New Moon.

# Eclipses

Almost every year, somewhere in the world the Sun disappears during daylight. This happens when the Moon passes between the Earth and the Sun, casting a shadow on the Earth and hiding all or part of the Sun from view. Such an event is called a solar eclipse. It may seem strange that a relatively small object like the Moon can hide a huge object like the Sun, which has a radius of more than 696,000 km. The answer lies in distance: the further away an object is, the smaller it looks. So although the Sun's diameter

![img-128.jpeg](img-128.jpeg)

is more than 400 times the diameter of the Moon, it can appear to be much the same size because it is between 367 and 419 times further from the Earth than the Moon is. When the Moon is closest to the Earth, it looks bigger than the Sun. This is when it can hide the Sun completely and cause a total eclipse.

What you see during an eclipse depends on where you are on Earth. You will see a total eclipse if you are in a place directly in line with the Sun and the Moon. In other places, you will see a partial eclipse with one edge of the Sun hidden by the Moon and the other edge visible.

The Moon itself can go into an eclipse, called a lunar eclipse. This happens when the Earth moves between the Sun and the Moon, casting its shadow on the Moon. At this time, the Moon almost disappears.

# Discussion

- In what way is the Moon important in daily life?

73

--

SCIENCE 10

# Radioactivity

![img-129.jpeg](img-129.jpeg)

The power station at Chernobyl, the site of the world's worst nuclear accident

Until April 1986, few people outside the Ukraine in Eastern Europe had heard of the town of Chernobyl. Then the nuclear power station there exploded. Clouds of radioactive dust spread over Eastern and Northern Europe. 250 people were killed and thousands of square kilometres were polluted. Even in Britain, more than 2,000 km away, animals were affected by the radioactive dust that fell from the sky.

# The discovery of radiation

The word radioactivity describes the changes that take place in the nucleus, or centre, of certain materials. When radioactivity occurs, rays are sent out. They were discovered in 1896, when a French chemist, Henri Becequerel, noticed that the metal uranium gave out rays that passed through other materials and affected photographic plates. He called these rays radiation.

# Effects

At that time, nobody knew about the effects of radiation on animal and plant cells. A small amount of radiation can cause cancer; long exposure to a large amount can result in death. Radiation caused the deaths of some of the early scientists working with it.

# Uses

Radiation can be used safely in many ways. One use is to find the age of dead plant and animal matter by measuring how much radiation it gives out. For example, the radiation from the bones of a dead animal can tell us when it died. Another use of radiation is to preserve food, because radiation can

destroy bacteria. Radiation is also used in medicine - in X-rays, for example.

# Nuclear power

The most important use of radioactivity is in nuclear power stations. There, electricity is generated in nuclear reactors using a radioactive process called nuclear fission. The nucleus of a Uranium-235 atom is split, or broken open. This causes the nucleus of another atom to split, then another, and so on in a chain reaction. Every time a nucleus is split, energy is released and heat is created. The heat is used to make steam, which drives the machines that generate electricity.

Nuclear power has two main advantages. First, there is enough uranium in the world to supply nuclear power stations for many hundreds of years. Secondly, nuclear power stations do not produce harmful gases. However, the accident at Chernobyl reminded the world of the dangers of radioactivity.

# Discussion

- Do you think nuclear power will ever replace oil?

74

--

![img-130.jpeg](img-130.jpeg)

الإدارة العامة للمناهج

+967771761429

Curricula.Ye@gmail.com

https://e-learning-moe.edu.ye

https://t.me/Books_Yemen_new

للحصول على المناهج
الدراسية عبر: